{
    'name': 'Hotel Folio',
    'summary': 'Manage Folios For Guest, Staff, Etc.',
    'description': """
                A folio is an account showing charges or payments made during a guest’s stay. 
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['mail', 'account', 'hotel_reservation', 'hotel_services','product'],
    'data': [
        'security/ir.model.access.csv',
        'security/ir.rule.xml',
        'data/hotel_folio_sequence.xml',
        'data/hotel_folios_tags.xml',
        'report/folio_report_template.xml',
        'report/hotel_folio_form_view_report.xml',
        'views/hotel_reservation_view.xml',
        'views/hotel_folio_view.xml',
        'views/hotel_folios_tags.xml',
        'views/hotel_room_inherit.xml',
        'wizard/advance_payment_wizard_view.xml',
        'wizard/folio_report_wizard_view.xml',
    ],
    'demo': [],
    'application ': True,
    'auto_install': True
}
