from odoo import fields, models


class FolioReportWizard(models.TransientModel):
    _name = 'folio.report.wizard'
    _description = 'Folio Report Details Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_folio_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.folio",
            "form": self.read(["start_date", "end_date"])[0],
        }
        date_records = self.env['hotel.folio'].search(
            [('order_date', '>=', self.start_date), ('order_date', '<=', self.end_date)])
        folio_data = []
        for rec in date_records:
            for line in rec.room_line_ids:
                folio_data.append({
                    'name': rec.name,
                    'date': rec.order_date,
                    'guests': rec.partner_id.name,
                    'room': line.room_id.name,
                    'total': rec.due_amount
                })
        data.update({
            'date_records': folio_data,
        })
        return self.env.ref('hotel_folio.folio_report').report_action(self, data=data)
