from odoo import fields, models
from odoo.exceptions import UserError, ValidationError


class AdvancePaymentWizard(models.TransientModel):
    _name = 'advance.payment.wizard'
    _description = 'Advance Payment Detail Wizard'

    amt = fields.Float('Amount')
    payment_journal_id = fields.Many2one('account.journal', "Journal", required=True,
                                         domain="[('type', 'in', ['cash','bank'])]")
    folio_id = fields.Many2one('hotel.folio', 'Folio Ref', default=lambda self: self._get_default_rec())
    payment_date = fields.Date('Payment Date', required=True, default=fields.Date.context_today)

    def _get_default_rec(self):
        res = {}
        if self._context is None:
            self._context = {}
        if 'folio_id' in self._context:
            res = self._context['folio_id']
        return res

    def payment_process(self):
        folio = self.folio_id
        if folio.total_amount < self.amt:
            raise UserError("Advance Amount Should not be greater than Total Amount.")
        if not self.payment_journal_id:
            raise ValidationError("Please Define Journal.")
        advance_payment_ref = "Advance payment of "
        payment_id = self.env['account.payment'].create({
            'amount': self.amt,
            'payment_type': 'inbound',
            'partner_type': 'customer',
            'partner_id': folio.partner_id.id,
            'journal_id': self.payment_journal_id.id,
            'ref': advance_payment_ref + folio.name
        })
        payment_id.action_post()
        folio.advance_paid_amount = payment_id.amount
        folio.is_advance_payment = True
        folio.payment_id = payment_id.id
        return {'type': 'ir.actions.act_window_close'}
