from . import account_move
from . import hotel_folio
from . import hotel_reservation_inherit
from . import hotel_room_line
from . import hotel_service_line
from . import hotel_folio_tags
from . import hotel_room_inherit
from . import room_book_history

