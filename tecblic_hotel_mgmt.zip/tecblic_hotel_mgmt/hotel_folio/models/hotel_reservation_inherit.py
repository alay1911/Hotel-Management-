from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _


class HotelReservation(models.Model):
    _inherit = "hotel.reservation"

    folio_ids = fields.One2many(comodel_name="hotel.folio", inverse_name="reservation_id", string="Folios")
    folio_count = fields.Integer(compute='compute_folio_count')
    show_updated_pricelist = fields.Boolean(string='Has Pricelist Changed')


    def create_folio(self):
        folio_obj = self.env['hotel.folio']
        if not self.folio_created:
            if self.is_multiple_folio:
                for rec in self.room_reservation_line_ids:
                    data = {
                        'reservation_id': self.id,
                        'order_date': self.order_date,
                        'partner_id': self.partner_id.id,
                        'pricelist_id': self.pricelist_id.id,
                        'state': 'draft',
                        'room_line_ids': [(0, 0, {'room_id': rec.room_id.id,
                                                  'check_in': rec.check_in,
                                                  'check_out': rec.check_out,
                                                  'tax_id': rec.tax_id.ids,
                                                  'rate': rec.rate,
                                                  'duration': rec.duration,
                                                  'room_type_id': rec.room_type_id.id,
                                                  'subtotal_amount': rec.subtotal_amount,
                                                  'tax_amount': rec.tax_amount,
                                                  'total_amount': rec.total_amount,
                                                  })],
                    }
                    folio_obj.create(data)
            else:
                data = {
                    'reservation_id': self.id,
                    'order_date': self.order_date,
                    'partner_id': self.partner_id.id,
                    'pricelist_id': self.pricelist_id.id,
                    'state': 'draft',
                    'room_line_ids': [(0, 0, {'room_id': rec.room_id.id,
                                              'check_in': rec.check_in,
                                              'check_out': rec.check_out,
                                              'tax_id': rec.tax_id.ids,
                                              'rate': rec.rate,
                                              'duration': rec.duration,
                                              'room_type_id': rec.room_type_id.id,
                                              'subtotal_amount': rec.subtotal_amount,
                                              'tax_amount': rec.tax_amount,
                                              'total_amount': rec.total_amount,
                                              }) for rec in self.room_reservation_line_ids],
                }
                folio_obj.create(data)
            self.folio_created = True

            service = self.env.ref('hotel_housekeeping.vacuum_activity').id
            housekeeping_data_list = []
            for room_reservation_line in self.room_reservation_line_ids:
                room_id = room_reservation_line.room_id
                housekeeping_data = {
                    'reservation_id': self.id,
                    'folio_id': self.folio_ids.id,
                    'room_id': room_id.id,
                    'activity_line_ids': [(0, 0, {
                        'activity_id': service,
                    })]
                }
                housekeeping_data_list.append(housekeeping_data)
            self.env['hotel.housekeeping'].create(housekeeping_data_list)

            # hotel_housekeeping = self.env['hotel.housekeeping'].search([('reservation_id','=',self.id)])
            # for line in self.folio_ids:
            #     today_date = self.check_in.date()
            #     for i in range(1, dur + 1):
            #         if hotel_housekeeping:
            #             line.housekeeping_line_ids = [(0, 0, {
            #                 'housekeeping_id':hotel_housekeeping.id,
            #                     'today_date': today_date,
            #                     # 'housekeeper_id': self.env.user.id,
            #                     'activity_id': service,
            #                 })]
            #         today_date += relativedelta(days=1)
            for rec in self.folio_ids:
                for line in rec.room_line_ids:
                    if line.room_type_id.with_breakfast:
                        food_ids = self.env['product.product'].search([('food_item_category', '=', self.env.ref('hotel_restaurant.restaurant_food_item_breakfast').id)])
                        restaurant_data = {
                            'is_hotel_guest': True,
                            'table_start_date': self.check_in,
                            'table_end_date': self.check_out,
                            'folio_id': rec.id,
                            'partner_id': self.partner_id.id,
                            'food_order_line_ids': [(0, 0, {
                                'food_id': food.id,
                                'rate': food.list_price,
                            }) for food in food_ids]
                        }
                        self.env['restaurant.table.order'].create(restaurant_data)
        return True

    def folio_smart_button(self):
        action = {
            'name': _('Folio'),
            'type': 'ir.actions.act_window',
            'res_model': 'hotel.folio',
            'context': {'default_reservation_id': self.id}
        }
        folio = self.env['hotel.folio'].search([('reservation_id', '=', self.id)])
        if len(folio) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': folio.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('reservation_id', '=', self.id)],
            })
        return action

    @api.depends("folio_ids")
    def compute_folio_count(self):
        for rec in self:
            rec.folio_count = rec.env['hotel.folio'].search_count([('id', 'in', rec.folio_ids.ids)])

    def folios_click_button(self):
        action = {
            'name': _('Folio'),
            'type': 'ir.actions.act_window',
            'res_model': 'hotel.folio',
            'context': {'default_reservation_id': self.id}
        }
        folio = self.env['hotel.folio'].search([('reservation_id', '=', self.id)])
        if len(folio) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': folio.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('reservation_id', '=', self.id)],
            })
        return action

    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        if self.partner_id:
            self.update(
                {
                    "pricelist_id": self.partner_id.property_product_pricelist.id,
                }
            )

    @api.onchange('pricelist_id', 'room_reservation_line_ids')
    def _onchange_pricelist_id(self):
        if self.room_reservation_line_ids and self.pricelist_id and self._origin.pricelist_id != self.pricelist_id:
            self.show_updated_pricelist = True
        else:
            self.show_updated_pricelist = False

    def update_prices(self):
        if self.pricelist_id.id:
            for line in self.room_reservation_line_ids:
                line.rate = line.room_id.list_price
                line.rate = line.rate * self.pricelist_id.currency_id.rate



