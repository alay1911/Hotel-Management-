from odoo import fields, models, api,_
from odoo.exceptions import  ValidationError

class HotelServiceLine(models.Model):
    _name = 'hotel.service.line'
    _description = 'Hotel Service Line'
    _rec_name = 'service_id'

    folio_id = fields.Many2one('hotel.folio', string='Folio')
    service_id = fields.Many2one('product.product', string='Service', domain="[('is_service','=',True)]")
    tax_id = fields.Many2many('account.tax', string='Taxes')
    rate = fields.Float(string="Rate")
    sub_total = fields.Float(string="Total")
    quantity = fields.Integer(string="Quantity", default=1)

    @api.onchange("service_id")
    def _onchange_service(self):
        if self.service_id.list_price:
            self.rate = self.service_id.list_price
        if self.service_id.taxes_id:
            self.tax_id = self.service_id.taxes_id.ids

    @api.onchange('quantity', 'rate')
    def _onchange_quantity(self):
        self.sub_total = self.rate * self.quantity

    @api.onchange("folio_id")
    def _onchange_room_type(self):
        services = []
        for rec in self:
            for line in rec.folio_id.room_line_ids:
                services += line.room_type_id.service_ids.ids
        return {'domain': {'service_id': [('id', 'in', services)]}}
