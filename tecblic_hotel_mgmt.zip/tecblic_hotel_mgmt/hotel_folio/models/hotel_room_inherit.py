from odoo import models, fields, api


class HotelRoomsInherit(models.Model):
    _inherit = 'product.product'

    rooms_history_ids = fields.One2many('room.book.history', 'room_id', string="History")