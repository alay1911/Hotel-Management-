from odoo import models, fields, api


class HotelRoomHistory(models.Model):
    _name = 'room.book.history'
    _description = "Room History"

    room_id = fields.Many2one('product.product', string='Room')
    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', tracking=True)
    folio_id = fields.Many2one('hotel.folio', string="Folio")
    room_type_id = fields.Many2one('product.category', string='Room Type')
    check_in = fields.Datetime(string="Check-In")
    check_out = fields.Datetime(string="Check-Out")
    total_amount=fields.Float(string="Total")
