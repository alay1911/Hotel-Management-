from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import requests


class HotelFolio(models.Model):
    _name = "hotel.folio"
    _inherit = [
        'mail.thread', 'mail.activity.mixin'
    ]
    _description = "Folio"

    name = fields.Char(string="Folio Reference", default="New")
    order_date = fields.Datetime(string="Order Date", tracking=True)
    partner_id = fields.Many2one(comodel_name="res.partner", string="Guest", tracking=True)
    room_line_ids = fields.One2many(comodel_name="hotel.room.line", inverse_name="folio_id",
                                    string="Room Lines")
    service_line_ids = fields.One2many(comodel_name="hotel.service.line", inverse_name="folio_id",
                                       string="Service Lines")
    company_id = fields.Many2one('res.company', string='Hotel', default=lambda self: self.env.company, tracking=True)
    user_id = fields.Many2one('res.users', string='User', default=lambda self: self.env.user, tracking=True)
    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', tracking=True, ondelete="cascade")
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('invoiced', "Invoiced"), ('done', 'Done'), ('cancel', 'Cancel')],
        string="Status", default="draft", tracking=True)
    # previous_total_amount = fields.Monetary(compute='_compute_total_amount', string="Previous Total Amount")
    total_amount = fields.Monetary(compute='_compute_total_amount', string="Total",store=True)
    tax_amount = fields.Monetary(compute='_compute_total_amount', string="Tax")
    untaxed_amount = fields.Monetary(compute='_compute_total_amount', string="Untaxed",store=True)
    pricelist_id = fields.Many2one(
        "product.pricelist",
        "Pricelist",
        states={"draft": [("readonly", False)]},
        help="Pricelist for current reservation.",
        tracking=True
    )
    currency_id = fields.Many2one(related='pricelist_id.currency_id', depends=["pricelist_id"], store=True,
                                  ondelete="restrict", tracking=True)
    invoice_ids = fields.One2many('account.move', "folio_id", 'Invoice', copy=False, tracking=True,
                                  domain=[('move_type', '=', 'out_invoice')])
    invoice_count = fields.Integer(compute="_compute_invoice_count", string="Invoice Count")
    tag_ids = fields.Many2many('folio.tag')
    advance_paid_amount = fields.Monetary(string="Advance Paid Amount")
    due_amount = fields.Monetary(compute="_compute_due_amount", string="Due Amount", store=True)
    is_advance_payment = fields.Boolean()
    paid_amount = fields.Monetary(compute="_compute_due_amount", string="Paid Amount", store=True)
    adv_payment_count = fields.Integer(compute='advance_payment_count')
    housekeeping_count = fields.Integer(compute='hotel_housekeeping_count')
    laundry_count = fields.Integer(compute='hotel_laundry_count')
    restaurant_count = fields.Integer(compute='hotel_restaurant_count')
    payment_id = fields.Many2one('account.payment')
    show_updated_pricelist = fields.Boolean(string='Has Pricelist Changed')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('hotel.folio') or _('New')
        res = super(HotelFolio, self).create(vals)
        return res

    @api.depends("room_line_ids", "service_line_ids", "untaxed_amount")
    def _compute_total_amount(self):
        for rec in self:
            included = excluded = tax = 0
            for room_line in rec.room_line_ids:
                res = room_line.tax_id.compute_all(room_line.rate, product=room_line.room_id,
                                                   partner=self.env['res.partner'])
                included += res['total_included']
                excluded += res['total_excluded']
                tax += included - excluded
            for service_line in rec.service_line_ids:
                res = service_line.tax_id.compute_all(service_line.rate, product=service_line.service_id,
                                                      partner=self.env['res.partner'])
                included += res['total_included']
                excluded += res['total_excluded']
                tax += included - excluded
            rec.untaxed_amount = excluded
            rec.tax_amount = tax
            rec.total_amount = included

    def draft_folio(self):
        for status in self:
            status.state = "draft"

    def confirm_folio(self):
        for rec in self:
            rec.state = "confirm"
            for line in rec.room_line_ids:
                line.room_id.rooms_history_ids = [(0, 0, {
                    'reservation_id': rec.reservation_id.id,
                    'folio_id': rec.id,
                    'room_id': line.room_id.id,
                    'room_type_id': line.room_type_id.id,
                    'check_in': line.check_in,
                    'check_out': line.check_out,
                    'total_amount': line.total_amount,
                })]

    def cancel_folio(self):
        for status in self:
            status.state = "cancel"

    def done_folio(self):
        payment = self.invoice_ids.mapped('payment_state')
        if not all(payment):
            raise ValidationError("All invoices should be Paid")
        else:
            if payment[0] != 'paid':
                raise ValidationError("All invoices should be Paid")
            self.state = 'done'

    def create_invoice(self):
        count = 1
        data = {
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'currency_id': self.currency_id.id,
            'date': fields.Date.today(),
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, {'sequence': count, 'name': 'Room Details', 'display_type': 'line_section'})],
            'ref': 'Folio Invoices'
        }
        for room in self.room_line_ids:
            count += 1
            data['invoice_line_ids'].append((0, 0, {
                'sequence': count,
                'product_id': room.room_id.id,
                'price_unit': room.rate,
                'tax_ids': room.tax_id.ids,
            }))
        if self.service_line_ids:
            count += 1
            data['invoice_line_ids'].append(
                (0, 0, {'sequence': count, 'name': 'Service Details', 'display_type': 'line_section'}))
            for service in self.service_line_ids:
                count += 1
                data['invoice_line_ids'].append((0, 0, {
                    'sequence': count,
                    'product_id': service.service_id.id,
                    'price_unit': service.rate,
                    'tax_ids': service.tax_id.ids,
                }))

        invoice = self.env['account.move'].create(data)
        invoice.action_post()
        self.invoice_ids = [(4, invoice.id)]
        self.state = 'invoiced'

    def action_invoices(self):
        action = {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'name': _('Invoices'),
            'context': {'search_default_group_by_ref': 1}
        }
        invoice = self.env['account.move'].search([('id', 'in', self.invoice_ids.ids)])
        if len(invoice) <= 1:
            action.update({
                'view_mode': 'form',
                'res_id': self.invoice_ids.ids[0],
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('id', 'in', self.invoice_ids.ids)],
            })
        return action

    @api.depends("invoice_ids")
    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = self.env['account.move'].search_count([('id', 'in', self.invoice_ids.ids)])

    @api.depends("advance_paid_amount", "total_amount", "invoice_ids.payment_state")
    def _compute_due_amount(self):
        for rec in self:
            paid = 0
            due = rec.total_amount
            for invoice in rec.invoice_ids:
                if invoice.payment_state == 'paid':
                    paid += self.env['account.payment'].search([('ref', '=', invoice.name)]).amount
            rec.paid_amount = paid
            if rec.paid_amount:
                due -= rec.paid_amount
            if rec.advance_paid_amount > 0:
                rec.due_amount = due - rec.advance_paid_amount
            else:
                rec.due_amount = due

    def advance_payment(self):
        ctx = dict(self._context)
        ctx['active_ids'] = [self]
        ctx['folio_id'] = self.id
        return {
            'name': _('Advance Payment'),
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'advance.payment.wizard',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': ctx,
        }

    @api.depends('payment_id')
    def advance_payment_count(self):
        for record in self:
            record.adv_payment_count = self.env['account.payment'].search_count(
                [('id', '=', self.payment_id.id)])

    def advance_payment_smart_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Advance Payment'),
            'view_mode': 'tree,form',
            'res_model': 'account.payment',
            'target': 'current',
            'domain': [('id', '=', self.payment_id.id)],
        }

    def unlink(self):
        for rec in self:
            if rec.state not in ['draft', 'cancel']:
                raise ValidationError("You cannot delete folio in Confirm, Invoiced and Done State!")
        return super(HotelFolio, self).unlink()

    @api.onchange('pricelist_id', 'room_line_ids')
    def _onchange_pricelist_id(self):
        if self.room_line_ids and self.pricelist_id and self._origin.pricelist_id != self.pricelist_id:
            self.show_updated_pricelist = True
        else:
            self.show_updated_pricelist = False

    def update_cur_rate(self):
        if self.pricelist_id.id:
            for hr in self.reservation_id.room_reservation_line_ids:
                for rec in self.room_line_ids:
                    if rec.room_id == hr.room_id:
                        rec.rate = hr.rate
                        rec.subtotal_amount = hr.subtotal_amount
                        rec.total_amount = hr.total_amount

                        rec.rate = rec.rate * self.pricelist_id.currency_id.rate
                        rec.subtotal_amount = rec.subtotal_amount * self.pricelist_id.currency_id.rate
                        rec.total_amount = rec.total_amount * self.pricelist_id.currency_id.rate
            for line in self.restaurant_line_ids:
                line.total_sale_price = line.food_order_line_ids.rate
                line.total_sale_price = line.total_sale_price * self.pricelist_id.currency_id.rate
        self._compute_total_amount()
        self._compute_due_amount()
        self.show_updated_pricelist = False

    def reservation_dashboard_folio_data(self):
        folio_count = self.search([('state', 'not in', ['cancelled'])])
        return {
            'total_folio_count': len(folio_count.ids),
            'total_folio': folio_count.ids,
            'total_draft_folio': folio_count.filtered(lambda rec: rec.state == 'draft').ids,
            'total_draft_folio_count': len(folio_count.filtered(lambda rec: rec.state == 'draft').ids),
            'total_confirm_folio': folio_count.filtered(lambda rec: rec.state == 'confirm').ids,
            'total_confirm_folio_count': len(folio_count.filtered(lambda rec: rec.state == 'confirm').ids),
            'total_invoiced_folio': folio_count.filtered(lambda rec: rec.state == 'invoiced').ids,
            'total_invoiced_folio_count': len(folio_count.filtered(lambda rec: rec.state == 'invoiced').ids),
            'total_done_folio': folio_count.filtered(lambda rec: rec.state == 'done').ids,
            'total_done_folio_count': len(folio_count.filtered(lambda rec: rec.state == 'done').ids),
        }
