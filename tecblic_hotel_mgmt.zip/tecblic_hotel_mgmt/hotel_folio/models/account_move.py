
from odoo import api, models,  fields



class AccountMove(models.Model):
    _inherit = "account.move"

    folio_id = fields.Many2one("hotel.folio", string="Folio")

