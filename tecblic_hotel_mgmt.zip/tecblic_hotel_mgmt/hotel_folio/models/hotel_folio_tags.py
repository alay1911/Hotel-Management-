from odoo import models, fields,api

class FolioTag(models.Model):
    _name = "folio.tag"
    _description = "Tags"

    name = fields.Char(string="Name")
    color = fields.Integer("Color")




