from odoo import fields, models


class HotelRoomLine(models.Model):
    _name = 'hotel.room.line'
    _description = 'Hotel Room Line'
    _rec_name = 'room_id'

    folio_id = fields.Many2one('hotel.folio', string='Folio')
    check_in = fields.Datetime(string="Check-In")
    check_out = fields.Datetime(string="Check-Out")
    room_id = fields.Many2one('product.product', string='Room',
                              domain="[('is_room','=',True),('state','=','available')]")
    capacity = fields.Integer(related='room_id.categ_id.capacity', string="Capacity")
    tax_id = fields.Many2many('account.tax', string='Taxes')
    rate = fields.Float(string="Rate")
    subtotal_amount = fields.Float(string="Subtotal")
    tax_amount = fields.Float(string="Tax")
    total_amount = fields.Float(string="Total")
    duration = fields.Float(string="Duration")
    room_type_id = fields.Many2one('product.category', string='Room Type', domain="[('is_room_type', '=', True)]")
