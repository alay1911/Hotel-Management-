from odoo import models, fields, api


class HotelReservation(models.Model):
    _name = "agent.commission.line"

    reservation_id = fields.Many2one('hotel.reservation')
    agent_id = fields.Many2one('agent.commission')
    customer_id = fields.Many2one("res.partner", string="Customer")
    total_cost = fields.Integer(string="Total Cost")
    commission_percentage = fields.Float(string="Commission(%)")
    commission_amount = fields.Float(string="Commission Amount")


    @api.onchange("reservation_id")
    def _onchange_service(self):
        if self.reservation_id.commission_partner_id:
            self.customer_id = self.reservation_id.commission_partner_id.id
        if self.reservation_id.commission_percentage:
            self.commission_percentage = self.reservation_id.commission_percentage
        if self.reservation_id.commission_amount:
            self.commission_amount = self.reservation_id.commission_amount
