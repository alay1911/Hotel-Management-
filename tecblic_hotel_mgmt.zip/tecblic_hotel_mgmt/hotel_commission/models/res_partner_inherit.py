from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = "res.partner"

    commission_count = fields.Integer(compute='_compute_commission_count')
    is_agent = fields.Boolean('Agent')

    def total_commissions(self):
        return {
            'name': 'Invoices',
            'type': 'ir.actions.act_window',
            'res_model': 'hotel.reservation',
            'view_mode': 'tree,form',
            'domain': [('commission_partner_id', '=', self.id)],

        }

    def _compute_commission_count(self):
        for rec in self:
            rec.commission_count = rec.env['hotel.reservation'].search_count([('commission_partner_id', '=', rec.id)])
