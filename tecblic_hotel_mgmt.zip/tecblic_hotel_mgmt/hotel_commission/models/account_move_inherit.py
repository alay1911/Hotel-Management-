from odoo import models, fields, api

class InvoiceInherit(models.Model):
    _inherit = 'account.move'

    commission_agent_id = fields.Many2one("agent.commission", string="Agent")