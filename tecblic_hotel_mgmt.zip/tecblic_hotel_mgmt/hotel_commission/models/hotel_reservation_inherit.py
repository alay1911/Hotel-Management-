from odoo import models, fields, api


class HotelReservation(models.Model):
    _inherit = "hotel.reservation"

    commission_partner_id = fields.Many2one('res.partner', string="Commission Agents", domain=[('is_agent', '=', True)])
    commission_amount = fields.Float(string="Commission Amount")
    commission_type = fields.Selection([('fixed', 'Fixed'), ('percentage', 'Percentage')], string="Commission Type")
    commission_percentage = fields.Float(string="Commission Percentage")

    @api.onchange("commission_type")
    def _onchange_amount(self):
        if self.commission_type == 'percentage':
            self.commission_amount = self.total_amount * (self.commission_percentage/100)

    def write(self, vals):
        res = super(HotelReservation, self).write(vals)
        print(">>>>res>>>",res)
        print(">>>>>vals>>", vals)
        if 'commission_partner_id' in vals:
            agent_comm = self.env['agent.commission'].search([('agent_id','=',vals.get('commission_partner_id'))])
            print('agent com', agent_comm)
            if not agent_comm:
                agent_comm = self.env['agent.commission'].create({
                    'agent_id': vals['commission_partner_id']
                })
            agent_comm.write({
                        'commission_line_ids': [(0, 0, {
                            'reservation_id': self.id,
                            'customer_id': self.commission_partner_id.id,
                            'total_cost': self.commission_amount,
                            'commission_percentage': self.commission_percentage,
                            'commission_amount': self.commission_amount,
                        })]
                    })
            return res






