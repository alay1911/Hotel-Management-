from . import hotel_reservation_inherit
from . import res_partner_inherit
from . import agent_commission
from . import agent_commission_line
from . import account_move_inherit
