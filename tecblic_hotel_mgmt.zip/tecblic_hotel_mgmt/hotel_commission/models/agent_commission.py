import datetime

from odoo import models, fields, api


class HotelReservation(models.Model):
    _name = "agent.commission"
    _rec_name = 'agent_id'

    agent_id = fields.Many2one("res.partner", string="Agent",domain="[('is_agent','=',True)]")
    pricelist_id = fields.Many2one("product.pricelist", string="Pricelist", help="Pricelist for Agent Commission.",tracking=True)
    date = fields.Date(string="Date")
    deposit_account = fields.Many2one("account.journal", string="Deposit Account")
    reservation_id = fields.Many2one('hotel.reservation')
    commission_line_ids = fields.One2many("agent.commission.line", "agent_id",
                                                string="Commission Lines")
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('invoiced', "Invoiced")], string="Status", default="draft", tracking=True)
    invoice_count = fields.Integer(compute="_compute_invoice_count", string="Invoice Count")

    def draft_commission(self):
        self.state = 'draft'

    def confirm_commission(self):
        self.state = 'confirm'

    def create_invoice(self):
        data = {
            'move_type': 'out_invoice',
            'partner_id': self.agent_id.id,
            'commission_agent_id': self.id,
            'invoice_date': self.date,
        }
        move = self.env['account.move'].create(data)
        if move:
            move.write({'state': 'posted'})
        self.state = 'invoiced'

    def action_invoices(self):
        action = {
            'name': 'Invoices',
            'type': 'ir.actions.act_window',
            'view_mode': 'form,tree',
            'res_model': 'account.move',
            'context': {'default_commission_agent_id': self.id}
        }
        invoice = self.env['account.move'].search([('commission_agent_id', '=', self.id)])
        if len(invoice) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': invoice.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('commission_agent_id', '=', self.id)],
            })
        return action

    @api.depends("invoice_count")
    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = self.env['account.move'].search_count([('commission_agent_id', '=', self.id)])

    # @api.onchange('agent_id')
    # def _onchange_agent(self):
    #     self.commission_line_ids = [(5,)]
    #     if self.agent_id:
    #         data = self.env['hotel.reservation'].search([('commission_partner_id', '=', self.agent_id.id)])
    #         self.commission_line_ids = [(0, 0, {'customer_id': rec.commission_partner_id.id,
    #                                   'reservation_id': rec.id,
    #                                   'commission_amount': rec.commission_amount,
    #                                   'commission_percentage': rec.commission_percentage,
    #                                   }) for rec in data]

