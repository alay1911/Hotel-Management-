{
    'name': 'Hotel Commission',
    'summary': 'Manage Commission For Hotels',
    'description': """
                Track of commissions for hotels  are managed by this module 
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['base','hotel_reservation','contacts','account'],
    'data': [
        'security/ir.model.access.csv',
        'views/hotel_commission_views.xml',
        'views/res_partner_inherit_views.xml',
        'views/agent_commission.xml',
    ],
    'demo': [],
    'application ': True,
    'auto_install': True
}
