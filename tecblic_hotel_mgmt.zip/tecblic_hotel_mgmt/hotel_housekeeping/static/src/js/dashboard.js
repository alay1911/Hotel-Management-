odoo.define('service_dashboard_tag', function (require) {
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');




    var ServicetemplateCalling = AbstractAction.extend({
        template: 'ServiceDashboard',
        events: {
            'click .dashboard-tile': '_onClick_info_box',
        },

        init: function (parent, data) {
            this.dashboards_templates = ['HotelDashBoardReservation'];
//            this.hotel_housekeeping = [];
            this.res_ids = [];
            return this._super.apply(this, arguments);
        },


        willStart: function () {
            var self = this;
            return $.when(ajax.loadLibs(this), this._super()).then(function () {
                return self.fetch_housekeeping_data();
                    // self.fetch_laundry_data();

            });
        },

        start: function() {
            var self = this;
            this.set("title", 'Dashboard');
            return this._super().then(function() {
                self.render_graphs();
                self.$el.parent().addClass('oe_background_grey');
            });
        },

        render_graphs: function(){
            var self = this;
            self.render_housekeeping();
            self.render_laundry();
        },


        render_housekeeping:function(){
            var self = this
                rpc.query({
                    model: "hotel.housekeeping",
                    method: "get_data",
                }).then(function (result) {
                     Object.entries(result).forEach(([key, value]) => {

                     $('#housekeeping_table').append('<tr><td>'+key+'</td><td class="housekeeping_table_value">'+value+'</td></tr>')
                });
            });
        },

        // render_laundry:function(){
        //     var self = this
        //         rpc.query({
        //             model: "laundry.order",
        //             method: "get_laundry_data",
        //         }).then(function (result) {
        //              Object.entries(result).forEach(([key, values]) => {
        //
        //              $('#laundry_table').append('<tr><td>'+key+'</td><td class="laundry_table_values">'+values+'</td></tr>')
        //         });
        //     });
        // },

        fetch_housekeeping_data: function () {
            var self = this;
            var def1 = this._rpc({
                model: 'hotel.housekeeping',
                method: 'get_total'
            }).then(function (result) {
                self.total_data = result['total_data']

            });
            return $.when(def1)
        },

        // fetch_laundry_data: function () {
        //     var self = this;
        //     var def1 = this._rpc({
        //         model: 'laundry.order',
        //         method: 'get_total_laundry'
        //     }).then(function (result) {
        //         self.total_laundry = result['total_laundry']
        //
        //     });
        //     return $.when(def1)
        // },



        _onClick_info_box: function (e) {
            var self = this;
            var info_box = this.$el.find(".dashboard-tile");
            var model_class = e.currentTarget;
            var data_model = model_class.getAttribute("data-model");
            var data_name = model_class.getAttribute("data-name");
            this.do_action({
                name: data_name,
                type: 'ir.actions.act_window',
                res_model: data_model,
                res_ids:self.res_ids,
                views: [[false, 'kanban'], [false, 'list'], [false, 'form']],
                view_mode: 'kanban,list,form',
                target: 'current',
            });
        },

    });

    core.action_registry.add('service_dashboard_tag', ServicetemplateCalling);

});





