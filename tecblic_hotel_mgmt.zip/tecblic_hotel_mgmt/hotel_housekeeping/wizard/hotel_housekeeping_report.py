from odoo import fields, models

class HousekeepingReportWizard(models.TransientModel):
    _name = 'housekeeping.report.wizard'
    _description = 'Housekeeping.Report.Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_housekeeping_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.housekeeping",
            "form": self.read(["start_date", "end_date"])[0],
        }
        date_records = self.env['hotel.housekeeping'].search(
            [('current_date', '>=', self.start_date), ('current_date', '<=', self.end_date)])
        service_data = []
        for rec in date_records:
             for line in rec.activity_line_ids:
                service_data.append({
                    'name': rec.name,
                    'date': rec.current_date,
                    'room': rec.room_id.name,
                    'activity': line.activity_id.name,
                    'start': line.clean_start_time,
                    'end': line.clean_end_time,
                })
        data.update({
            'date_records': service_data,
        })
        return self.env.ref('hotel_housekeeping.hotel_housekeeping_report').report_action(self,data=data)

