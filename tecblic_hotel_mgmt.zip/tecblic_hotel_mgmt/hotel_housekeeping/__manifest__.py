{
    'name': 'Hotel Housekeeping',
    'summary': 'Manage Hotel Housekeeping',
    'description': """
                Manage Hotel Housekeeping.
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company':'Tecblic Private Limited',
    'website' : 'https://www.tecblic.com',
    'depends':['hotel_reservation','hotel_folio','hotel_services','hotel_laundry'],
    'data': [
        'security/ir.rule.xml',
        'security/ir.model.access.csv',
        'data/menu.xml',
        'data/activity_category.xml',
        'data/activity_types.xml',
        'data/hotel_housekeeping_sequence.xml',
        'report/hotel_housekeeping_report_template.xml',
        'report/hotel_housekeeping_form_view_report.xml',
        'views/hotel_housekeeping_views.xml',
        'views/activities_views.xml',
        'views/acitivity_catagory_views.xml',
        'views/hotel_folio_inherit_views.xml',
        'wizard/hotel_housekeeping_view.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'hotel_housekeeping/static/src/js/dashboard.js',
            'hotel_housekeeping/static/src/css/adminlte.min.css',
        ],
        'web.assets_qweb': [
            'hotel_housekeeping/static/src/xml/dashboard_templates.xml',
        ],
    },
    'demo': [],
    'application ': True,
    'auto_install': True
}