from odoo import models, api
from datetime import datetime


class LaundryData(models.Model):
    _inherit = 'laundry.order'

    @api.model
    def get_laundry_data(self):
        laundry = self.env['laundry.order'].search([])
        values = {}
        for rec in laundry:
            values[rec.partner_id.name] = rec.state
        return values

    @api.model
    def get_total_laundry(self):
        laundry = self.env['laundry.order'].search([])
        return {
            'total_laundry': len(laundry)
        }