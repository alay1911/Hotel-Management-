from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class HotelHousekeepingActivities(models.Model):

    _name = "hotel.housekeeping.activities"
    _description = "Housekeeping Activities"

    housekeeping_id = fields.Many2one("hotel.housekeeping", "Reservation")
    # today_date = fields.Date()
    today_date = fields.Date("Date", default=fields.Date.today)
    activity_id= fields.Many2one("activities", "Housekeeping Activity")
    housekeeper_id = fields.Many2one("res.users", "Attendant")
    clean_start_time = fields.Datetime()
    clean_end_time = fields.Datetime()
    
    # is_start = fields.Char("Start")
    # is_end = fields.Char("End")
    def set_to_start(self):
        self.clean_start_time = fields.Datetime.now()

    def set_to_end(self):
        self.clean_end_time = fields.Datetime.now()