from odoo import fields, models, api

class HotelHouseKeepingLine(models.Model):
    _name = 'hotel.housekeeping.line'
    _description = 'Hotel Housekeeping Line'

    folio_id = fields.Many2one('hotel.folio', string='Room')
    activity_id = fields.Many2one("activities", "Housekeeping Activity")
    today_date = fields.Date("Date")
    housekeeper_id = fields.Many2one("res.users", "Attendant")
    clean_start_time = fields.Datetime()
    clean_end_time = fields.Datetime()
    housekeeping_id = fields.Many2one("hotel.housekeeping",string="Reference")
    current_date = fields.Date("Date", default=fields.Date.today)
    clean_type = fields.Selection([
                                ("daily", "Daily"),
                                ("checkin", "Check-In"),
                                ("checkout", "Check-Out"),
                                ],string="Clean Type", default="daily")
    assign_to = fields.Many2one("res.users", string="Assign To", default=lambda x:x.env.user.id)


    def set_to_start(self):
        self.clean_start_time = fields.Datetime.now()

    def set_to_end(self):
        self.clean_end_time = fields.Datetime.now()
