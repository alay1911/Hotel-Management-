from odoo import models, fields, _


class ReservationHousekeeping(models.Model):
    _inherit = 'hotel.folio'

    housekeeping_line_ids = fields.One2many("hotel.housekeeping.line" ,"folio_id",
                                        string="Housekeeping Lines")

    def hotel_housekeeping_count(self):
        for record in self:
            record.housekeeping_count = self.env['hotel.housekeeping'].search_count(
                [('folio_id', 'in', self.ids)])

    def housekeeping_smart_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Housekeeping'),
            'view_mode': 'tree,form',
            'res_model': 'hotel.housekeeping',
            'target': 'current',
            'domain': [('folio_id', 'in', self.ids)],
            'context': {
                'default_folio_id': self.reservation_id.folio_ids.id,
            }
        }

