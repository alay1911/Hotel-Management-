from odoo import models, fields


class ActivityCategory(models.Model):
    _name = "activity.category"
    _description = "Activity Category"

    sequence = fields.Integer("sequence", default=10)
    name = fields.Char(string="Activity Category")