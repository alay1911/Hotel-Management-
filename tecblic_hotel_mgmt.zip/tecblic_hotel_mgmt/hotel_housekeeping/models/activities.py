from odoo import models, fields


class HousekeepingActivities(models.Model):
    _name = "activities"
    _inherit = [
        'mail.thread', 'mail.activity.mixin'
    ]
    _description = "Housekeeping Activities"

    name = fields.Char(string="Acitivity", tracking=True)
    description = fields.Html(string="Description")
    activity_category_id = fields.Many2one(comodel_name='activity.category', string='Activity Category', help='Activity Category')
    is_paid = fields.Boolean(string="Is Paid")
    rate = fields.Float(string="Rate")
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)