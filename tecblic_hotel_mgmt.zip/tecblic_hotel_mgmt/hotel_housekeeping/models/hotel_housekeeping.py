from odoo import models, fields, _ ,api
from datetime import  datetime, date


class HotelHousekeeping(models.Model):
    _name = "hotel.housekeeping"
    _description = "Hotel Housekeeping"

    name = fields.Char(string="Housekeeping Reference", default="New")
    current_date = fields.Date("Date", default=fields.Date.today)
    start_date_time = fields.Datetime("Start Date", default=fields.Date.today)
    end_date_time = fields.Datetime("End Date")
    clean_type = fields.Selection([
                                ("daily", "Daily"),
                                ("checkin", "Check-In"),
                                ("checkout", "Check-Out"),
                                ],string="Clean Type", default="daily")
    assign_to = fields.Many2one("res.users", string="Assign To", default=lambda x:x.env.user.id)
    room_id = fields.Many2one(
                        "product.product",
                        "Room No.",domain="[('is_room', '=', True)]")
    inspector_name = fields.Many2one('res.partner',"Inspector")
    inspect_date_time = fields.Datetime("Inspect Date Time")
    state = fields.Selection([
                            ("new", "New"),
                            ("inprogress", "Inprogress"),
                            ("ready", "Ready"),
                            ("done", "Done"),
                            ("reject", "Rejected"),
                            ("cancel", "Cancelled"),
                            ],
                            states={"done": [("readonly", True)]},
                            default="new",
                            )
    activity_line_ids = fields.One2many(
                        "hotel.housekeeping.activities",
                        "housekeeping_id",
                        "Activities",
                        states={"done": [("readonly", True)]},
                        help="Detail of housekeeping activities",
                    )
    reservation_id = fields.Many2one(
                        "hotel.reservation",
                        "Reservation",
                        related="folio_id.reservation_id")
    folio_id = fields.Many2one(
                        "hotel.folio",
                        "Folio")
    company_id = fields.Many2one('res.company', string='Hotel', default=lambda self: self.env.company, tracking=True)

    @api.onchange('folio_id')
    def _onchange_folio_id(self):
        room_ids = []
        for room in self.folio_id.room_line_ids:
            room_ids.append(room.room_id.id)

        return {'domain': {'room_id': [('id', 'in', room_ids)]}}

    def set_start_cleaning(self):
        self.write({"state": "inprogress"})

    def set_mark_ready(self):
        self.write({"state": "ready"})


    def set_mark_done(self):
        self.write({"state": "done",
                    "end_date_time":datetime.today()})

    def set_reject_cleaning(self):
        self.write({"state": "reject"})

    def set_cancel_cleaning(self):
        self.write({"state": "cancel"})


    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'hotel.housekeeping') or _('New')
        res = super(HotelHousekeeping, self).create(vals)
        return res


    @api.model
    def get_data(self):
        hotel_housekeeping = self.env['hotel.housekeeping'].search([])
        value = {}
        for rec in hotel_housekeeping:
            value[rec.name] = rec.state
        return value

    @api.model
    def get_total(self):
        hotel_housekeeping = self.env['hotel.housekeeping'].search([])
        return {
            'hotel_housekeeping': hotel_housekeeping,
            'total_data': len(hotel_housekeeping)
        }

