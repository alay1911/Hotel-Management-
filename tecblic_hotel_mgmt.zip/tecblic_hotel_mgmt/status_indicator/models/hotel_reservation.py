from odoo import api, fields, models


class Hotel_Reservation(models.Model):
    _inherit = 'hotel.reservation'

    reservation_status = fields.Selection(compute='_reservation_status', method=True,
                                          selection=[('draft', 'Draft'),
                                                    ('reserved', 'Reserved'),
                                                    ('verified', 'Verified'),
                                                    ('booked', 'Booked'),
                                                    ('check_in', 'Check In'),
                                                    ('check_out', 'Check Out'),
                                                    ('cancelled', 'Cancelled'),
                                                    ('done', 'Done')], string='Reservation Status', store=True)

    status_color = fields.Integer(compute='_check_color', method=True, string='Colour')

    @api.depends('state')
    def _reservation_status(self):
        d = 0
        for val in self:
            val.reservation_status = {
                'draft' : 'draft',
                'reserved' : 'reserved',
                'verified' : 'verified',
                'booked' : 'booked',
                'check_in' : 'check_in',
                'check_out' : 'check_out',
                'cancelled' : 'cancelled',
                'done': 'done'
            }.get(val.state, False)

    
    @api.depends('state')
    def _check_color(self):
        for val in self:
            val.status_color = ['draft','reserved' , 'verified','booked' , 'check_in', 'check_out', 'cancelled' ,'done'].index(val.state)




class HotelFolioInherit(models.Model):
    _inherit = 'hotel.folio'

    folio_status = fields.Selection(compute='_folio_status', method=True,
                                          selection=[('draft', 'Draft'),
                                                     ('confirm', 'Confirm'),
                                                     ('cancel', 'Cancel'),
                                                     ('invoiced', "Invoiced"),
                                                     ('done', 'Done')], string='Folio Status', store=True)
    
    status_color = fields.Integer(compute='_check_color', method=True, string='Colour')


    @api.depends('state')
    def _folio_status(self):
         for record in self:
            record.folio_status = record.state


    @api.depends('state')
    def _check_color(self):
        for record in self:
            colors = ['draft', 'confirm', 'cancel', 'invoiced', 'done']
            record.status_color = colors.index(record.state) if record.state in colors else -1



class HotelRoomInherit(models.Model):
    _inherit = 'product.product'

    room_status = fields.Selection(compute='_room_status', method=True,
                                    selection=[("available", "Available"),
                                            ("occupied", "Occupied")], string='Room Status', store=True)

    status_color = fields.Integer(compute='_check_color', method=True, string='Colour')

    
    @api.depends('state')
    def _room_status(self):
        for record in self:
            record.room_status = record.state

    @api.depends('state')
    def _check_color(self):
        for record in self:
            colors = ['available', 'occupied']
            record.status_color = colors.index(record.state) if record.state in colors else -1
