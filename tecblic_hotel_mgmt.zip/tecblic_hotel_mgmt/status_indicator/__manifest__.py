{
    'name': "status_indicator",
    'summary': """status_indicator
        """,
    'description': """
        status_indicator
    """,
    'category': '',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['web','hotel_reservation','hotel_housekeeping','base'],
    'data': [
        'views/hotel_reservation.xml',
        'views/hotel_folio.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'status_indicator/static/src/css/project_task_state.css',
            'status_indicator/static/src/js/FormRenderer.js',
        ],
    },
    
    'demo': [],
    'application ': True,
    'auto_install': True

}
