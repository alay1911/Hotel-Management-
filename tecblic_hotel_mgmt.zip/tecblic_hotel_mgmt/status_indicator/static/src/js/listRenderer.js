odoo.define('project_status_indicator.ListRenderer', function (require) {
"use strict";

const ListRenderer =require('web.ListRenderer');
ListRenderer.include({
    _renderBodyCell: function (record, node, colIndex, options) {
        var self = this
        var res = this._super.apply(this, arguments);
        if(node.tag == 'field' && $(res).hasClass('show_deadline_color') && record.data.state != 'confirm')
            $(res).addClass('text-danger');
        if(node.tag == 'button_group'){
            const fields = (self.state || {}).fields || {}
            if (!_.isEmpty(fields)){
                if (fields.state){
                    var selection  = fields.state.selection || []
                    selection = _.filter(selection, function(el, idx){
                        return el[0] == record.data.state
                    });
                    if(selection.length)
                        $(res).find('.color_status').attr('title', selection[0][1]);
                }
            }
        }
        return res
    }
  });
});
