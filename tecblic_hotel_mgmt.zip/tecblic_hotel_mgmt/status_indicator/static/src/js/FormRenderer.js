odoo.define('project_status_indicator.FormRenderer', function (require) {
"use strict";
const FormRenderer =require('web.FormRenderer');

FormRenderer.include({
    _renderTagForm: function (node) {
             var self = this
             var res = this._super.apply(this, arguments);

             if($(res).find('.color_status')){
                          const fields = (self.state || {}).fields || {}
               if (!_.isEmpty(fields)){
                if (fields.state){
                var sel = _.filter(self.state.fields.state.selection ,function(el,idx){return el[0]==self.state.data.state})
                            if(sel[0])
                            {$(res).find('.oe_right').attr('title', sel[0][1]);}

                }};
             };


             return res
             }
});

});
