{
    'name': 'Hotel Dashboard',
    'summary': 'Hotel Dashboard',
    'description': """
                Hotel Dashboard.
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': [],
    'data': [
        'views/hotel_dashboard_menus.xml'
    ],
    'demo': [],
    'application ': True,
    'auto_install': True,
}
