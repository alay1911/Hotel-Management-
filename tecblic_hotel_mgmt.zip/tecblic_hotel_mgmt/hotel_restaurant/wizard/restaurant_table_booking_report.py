from odoo import fields, models, api


class RestaurantTableBookingReport(models.TransientModel):
    _name = "restaurant.table.booking.wizard"
    _description = "Restaurant.table.booking.Wizard"

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def print_table_booking(self):
        data = {
            "ids": self.ids,
            "model": "restaurant.table.booking",
            "form": self.read(["start_date", "end_date"])[0],
        }
        records = self.env['restaurant.table.booking'].search(
            [('table_booking_date', '>=', self.start_date), ('table_booking_date', '<=', self.end_date)])
        booking_data = []
        for i in records:
            for reco in i.restaurant_table_ids:
                booking_data.append({
                    'name': i.name,
                    'customer': i.customer_name.name,
                    'phone': i.phone,
                    'date': i.table_booking_date,
                    'guest': i.num_guests,
                    'table': reco.table_id
                })
        data.update({
            'records': booking_data,
        })
        return self.env.ref('hotel_restaurant.restaurant_table_booking_report').report_action(self,data=data)

