from odoo import fields, models, api


class RestaurantOrderReport(models.TransientModel):
    _name = "restaurant.order.wizard"
    _description = "Restaurant Order Wizard"

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def print_restaurant_order(self):
        data = {
            "ids": "self.ids",
            "model": "restaurant.table.order",
            "form": self.read(["start_date", "end_date"])[0],
        }
        records = self.env['restaurant.table.order'].search(
            [('order_reservation_date', '>=', self.start_date), ('order_reservation_date', '<=', self.end_date)])
        order_data = []
        for i in records:
             for reco in i.table_ids:
                    order_data.append({
                        'name': i.name,
                        'start':i.table_start_date,
                        'end':i.table_end_date,
                        'waiter':i.waiter_name.name,
                        'table':reco.table_id,
                        'total':i.total_sale_price
                })
        data.update({
            'records': order_data,
        })
        return self.env.ref('hotel_restaurant.restaurant_table_order_report').report_action(self,data=data)
