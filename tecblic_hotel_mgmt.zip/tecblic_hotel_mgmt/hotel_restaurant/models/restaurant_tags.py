from odoo import models, fields,api

class HotelRestaurantTag(models.Model):
    _name = "restaurant.tag"
    _description = "Tags"

    name = fields.Char(string="Name")
    color = fields.Integer("Color")
