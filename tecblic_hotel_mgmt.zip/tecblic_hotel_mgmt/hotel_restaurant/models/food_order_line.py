from odoo import fields, models, api


class FoodOrderLine(models.Model):
    _name = 'food.order.line'
    _description = 'Food Order Line'

    restaurant_kitchen_order_id = fields.Many2one('restaurant.kitchen.order')
    restaurant_table_order_id = fields.Many2one('restaurant.table.order')
    quantity = fields.Integer(default=1)
    food_id = fields.Many2one('product.product', domain=[('is_food_item', '=', True)])
    rate = fields.Float()
    total_rate = fields.Float(compute="_compute_total_rate", store=True)
    is_ordered = fields.Boolean()

    @api.onchange("food_id")
    def _onchange_food(self):
        if self.food_id:
            self.rate = self.food_id.lst_price

    @api.depends("quantity", "rate")
    def _compute_total_rate(self):
        for rec in self:
            if rec.rate and rec.quantity:
                rec.total_rate = rec.rate * rec.quantity
            else:
                rec.total_rate = rec.rate
