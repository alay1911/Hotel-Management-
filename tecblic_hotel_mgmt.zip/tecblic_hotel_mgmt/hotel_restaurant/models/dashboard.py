from odoo import models, api


class RestaurantDashboard(models.Model):
    _inherit = 'restaurant.table.booking'

    @api.model
    def retrieve_dashboard(self):
        total_draft_tables = self.env['restaurant.table.booking'].search_count([('state', '=', 'draft')])
        total_confirmed_tables = self.env['restaurant.table.booking'].search_count([('state', '=', 'confirm')])
        total_done_tables = self.env['restaurant.table.booking'].search_count([('state', '=', 'done')])

        total_draft_orders = self.env['restaurant.table.order'].search_count([('state', '=', 'draft')])
        total_confirmed_orders = self.env['restaurant.table.order'].search_count([('state', '=', 'confirm')])
        total_done_orders = self.env['restaurant.table.order'].search_count([('state', '=', 'done')])

        total_kitchen_orders = self.env['restaurant.kitchen.order'].search_count([])
        total_food_items = self.env['product.product'].search_count([('is_food_item','=',True)])
        total_food_item_types = self.env['product.category'].search_count([('is_food_type','=',True)])
        total_tables = self.env['restaurant.table'].search_count([])

        result = {
            'total_draft_tables': total_draft_tables,
            'total_confirmed_tables': total_confirmed_tables,
            'total_done_tables': total_done_tables,
            'total_draft_orders': total_draft_orders,
            'total_confirmed_orders': total_confirmed_orders,
            'total_done_orders': total_done_orders,
            'total_kitchen_orders': total_kitchen_orders,
            'total_food_items': total_food_items,
            'total_food_item_types': total_food_item_types,
            'total_tables': total_tables,
        }
        return result
