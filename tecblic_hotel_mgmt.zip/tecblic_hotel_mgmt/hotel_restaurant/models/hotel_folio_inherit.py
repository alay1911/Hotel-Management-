from odoo import models, fields, api, _


class HotelFolio(models.Model):
    _inherit = "hotel.folio"

    restaurant_line_ids = fields.One2many('restaurant.table.order','folio_id',string="Restaurant Lines")

    def create_restaurant_order_1(self):
        ctx = {
            'default_reservation_id': self.reservation_id.id,
            'default_folio_id': self.id,
            'default_partner_id': self.partner_id.id,
            'default_is_hotel_guest': True
        }
        return {
            'name': _('Restaurant Order'),
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('hotel_restaurant.restaurant_table_order_form_view_reservation').id,
            'res_model': 'restaurant.table.order',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': ctx
        }

    def hotel_restaurant_count(self):
        for record in self:
            record.restaurant_count = self.env['restaurant.table.order'].search_count(
                [('folio_id', 'in', self.ids)])

    def restaurant_smart_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Restaurant Table Order'),
            'view_mode': 'tree,form',
            'res_model': 'restaurant.table.order',
            'target': 'current',
            'domain': [('folio_id', 'in', self.ids)],
            'context': {
                'default_is_hotel_guest': True,
                'default_reservation_id': self.reservation_id.id,
                'default_order_date': self.reservation_id.order_date,
                'default_folio_id': self.reservation_id.folio_ids.id,
                'default_partner_id': self.reservation_id.partner_id.id,
            }
        }
        