from odoo import models, fields


class FoodItem(models.Model):
    _inherit = 'product.product'
    _description = "Food Item"

    is_food_item = fields.Boolean()
    food_item_category = fields.Many2one('product.category',domain="[('is_food_type','=',True)]")
