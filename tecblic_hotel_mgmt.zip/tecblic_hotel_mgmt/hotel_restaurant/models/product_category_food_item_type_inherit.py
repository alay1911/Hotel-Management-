from odoo import models, fields, api


class FoodItemType(models.Model):
    _inherit = 'product.category'
    _description = "Food Item Type"

    is_food_type = fields.Boolean()

