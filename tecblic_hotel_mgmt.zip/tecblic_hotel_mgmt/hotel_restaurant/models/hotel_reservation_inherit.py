from odoo import fields, models, _, api


class HotelReservation(models.Model):
    _inherit = 'hotel.reservation'

    restaurant_order_ids = fields.One2many("restaurant.table.order", 'reservation_id')
    restaurant_order_count = fields.Integer(compute='_compute_restaurant_order_count')

    def create_restaurant_order(self):
        ctx = {
            'default_reservation_id': self.id,
            'default_partner_id': self.partner_id.id,
            'default_is_hotel_guest': True
        }
        return {
            'name': _('Restaurant Order'),
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('hotel_restaurant.restaurant_table_order_form_view_reservation').id,
            'res_model': 'restaurant.table.order',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': ctx
        }

    def action_restaurant_order(self):
        action = {
            'type': 'ir.actions.act_window',
            'res_model': 'restaurant.table.order',
            'name': _('Restaurant Orders'),
        }
        if len(self.restaurant_order_ids.ids) <= 1:
            action.update({
                'view_mode': 'form',
                'res_id': self.restaurant_order_ids.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('id', 'in', self.restaurant_order_ids.ids)],
            })
        return action

    @api.depends('restaurant_order_ids')
    def _compute_restaurant_order_count(self):
        for rec in self:
            if rec.restaurant_order_ids:
                rec.restaurant_order_count = len(rec.restaurant_order_ids.ids)
            else:
                rec.restaurant_order_count = 0
