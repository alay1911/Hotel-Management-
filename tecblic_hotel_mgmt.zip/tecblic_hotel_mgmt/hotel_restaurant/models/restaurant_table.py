from odoo import models, fields, api, _


class RestaurantTable(models.Model):
    _name = "restaurant.table"
    _description = "Hotel Restaurant Table"
    _rec_name = 'table_id'

    table_id = fields.Char("Table Number")
    capacity = fields.Integer("Capacity")
    state = fields.Selection(
        [("available", "Available"),
         ("occupied", "Occupied")],
        default="available", tracking=True
    )
    table_category_id=fields.Many2one('table.category',string='Table Type')
    table_tag_ids = fields.Many2many('table.tag')

    def available_table(self):
        self.state = "available"

    def occupied_table(self):
        self.state = "occupied"