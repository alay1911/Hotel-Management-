import datetime

from odoo import models, fields, api, _, exceptions
from odoo.exceptions import ValidationError


class RestaurantTableOrder(models.Model):
    _name = "restaurant.table.order"
    _description = "Hotel Restaurant Table Order"

    name = fields.Char("Order Reference", default=lambda self: _('New'))
    is_hotel_guest = fields.Boolean(string="Is Hotel Guest?", tracking=True)
    order_reservation_id = fields.Many2one('restaurant.table.booking', string='Table Reservation', tracking=True)
    order_reservation_date = fields.Datetime(string='Table Reservation Date', tracking=True)
    table_ids = fields.Many2many('restaurant.table', tracking=True)
    waiter_name = fields.Many2one('res.users', string='Waiter', tracking=True)
    folio_id = fields.Many2one('hotel.folio', string='Folio No.', tracking=True)
    room_id = fields.Many2one('product.product', string='Room No.', domain="[('is_room','=',True)]", tracking=True)
    table_start_date = fields.Datetime(string='Start Time', tracking=True)
    table_end_date = fields.Datetime(string='End Time', tracking=True)
    kitchen_order_count = fields.Integer(compute='kitchen_count', tracking=True)
    tag_ids = fields.Many2many('table.tag')
    partner_id = fields.Many2one('res.partner', string='customer')
    reservation_id = fields.Many2one('hotel.reservation', string="Reservation")
    order_date = fields.Datetime(
        "Date", default=lambda self: fields.Datetime.now(), tracking=True
    )
    state = fields.Selection(
        [("draft", "Draft"), ("order", "Order Created"), ("invoiced", "Invoiced"), ("done", "Done")],
        required=True,
        readonly=True,
        default="draft",
        tracking=True
    )
    currency_id = fields.Many2one('res.currency', store=True, default=lambda self: self.env.company.currency_id)
    total_sale_price = fields.Monetary(compute='_compute_total_sale_price', string='Total',
                                       currency_field='currency_id', store=True)
    invoice_count = fields.Integer(compute='_compute_invoice_count')

    food_order_line_ids = fields.One2many(comodel_name="food.order.line", inverse_name="restaurant_table_order_id",
                                          string="Food Orders")

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'restaurant.table.order') or _('New')
        res = super(RestaurantTableOrder, self).create(vals)
        return res

    def get_kitchen_order_data(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Kitchen Order',
            'view_mode': 'list,form',
            'res_model': 'restaurant.kitchen.order',
            'domain': [('kitchen_order_ref_id', '=', self.id)],
        }

    def kitchen_count(self):
        for record in self:
            record.kitchen_order_count = self.env['restaurant.kitchen.order'].search_count(
                [('kitchen_order_ref_id', '=', self.id)])

    def generate_kitchen_order(self):
        if not self.food_order_line_ids:
            raise exceptions.ValidationError("Please add food items.")
        self.state = "order"
        kitchen_order_obj = self.env['restaurant.kitchen.order']
        vals = []
        for rec in self.food_order_line_ids:
            if not rec.is_ordered:
                vals.append((0, 0, {'food_id': rec.food_id.id, 'quantity': rec.quantity, 'rate': rec.rate}))
                rec.is_ordered = True
        data = {
            'kitchen_order_ref_id': self.id,
            'kitchen_order_reservation_id': self.order_reservation_id.name,
            'kitchen_waiter_name': self.waiter_name.name,
            'kitchen_order_ids': vals,
            'kitchen_table_ids': self.table_ids.ids
        }
        kitchen_order_obj.create(data)
        return True

    def done_table_order(self):
        move = self.env['account.move'].search([('restaurant_order_id', '=', self.id)])
        if move.payment_state == 'paid':
            self.write({"state": "done"})
            message = "Order Done!"
            return {
                'effect': {
                    'fadeout': 'slow',
                    'type': 'rainbow_man',
                    'message': _(message),
                }
            }
        else:
            raise ValidationError("The invoice should be Paid!")

    def update_food_items(self):
        is_update = False
        if not self.food_order_line_ids:
            raise exceptions.ValidationError("Please add more food items to update your order")
        table_order_id = self.env['restaurant.kitchen.order'].search([('kitchen_order_ref_id', '=', self.id)])
        for rec in self.food_order_line_ids:
            if not rec.is_ordered:
                is_update = True
                table_order_id.kitchen_order_ids = [
                    (0, 0, {'food_id': rec.food_id.id, 'quantity': rec.quantity, 'rate': rec.rate})]
                rec.is_ordered = True
        message = "Order is already up to date !"
        if is_update:
            message = "Order updated !"
        return {
            'effect': {
                'fadeout': 'slow',
                'type': 'rainbow_man',
                'message': _(message),
            }
        }

    @api.depends('food_order_line_ids')
    def _compute_total_sale_price(self):
        for record in self:
            if record.food_order_line_ids:
                record.total_sale_price = sum(record.food_order_line_ids.mapped('total_rate'))
            else:
                record.total_sale_price = 0

    def generate_invoice(self):
        generate_invoice_obj = self.env['account.move']
        vals = []
        for rec in self.food_order_line_ids:
            vals.append((0, 0, {'product_id': rec.food_id.id, 'name': rec.food_id.name, 'price_unit': rec.rate,
                                'quantity': rec.quantity}))
        data = {
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'restaurant_order_id': self.id,
            'invoice_date': datetime.date.today(),
            'invoice_line_ids': vals,
            'ref': 'Restaurant Invoices'
        }
        if self.folio_id:
            data['folio_id'] = self.folio_id.id
        account_move = generate_invoice_obj.create(data)
        self.write({"state": "invoiced"})
        if account_move:
            account_move.write({"state": "posted"})
            account_move.write({'payment_reference': account_move.name})
            message = "Invoice Created!"
            return {
                'effect': {
                    'fadeout': 'slow',
                    'type': 'rainbow_man',
                    'message': _(message),
                }
            }

    def get_table_invoices(self):
        account_move = self.env['account.move'].search([('restaurant_order_id', '=', self.id)])
        action = {
            'name': _('Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'context': {'default_reservation_id': self.id}
        }
        if len(account_move) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': account_move.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('reservation_id', '=', self.id)],
            })
        return action

    @api.onchange('folio_id')
    def _onchange_folio(self):
        self.partner_id = self.folio_id.partner_id

    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = self.env['account.move'].search_count([('restaurant_order_id', '=', self.id)])
