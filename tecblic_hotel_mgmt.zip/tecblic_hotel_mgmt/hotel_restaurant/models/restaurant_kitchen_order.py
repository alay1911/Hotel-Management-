from odoo import models, fields, api, _


class RestaurantKitchenOrder(models.Model):
    _name = "restaurant.kitchen.order"
    _description = "Restaurant Kitchen Order"

    name = fields.Char("Kitchen Order Number", default=lambda self: _('New'))
    kitchen_order_ref_id = fields.Many2one('restaurant.table.order', string='Order Reservation', tracking=True)
    kitchen_order_reservation_id = fields.Char(string='Table Reservation', tracking=True)
    kitchen_order_date = fields.Datetime(string='Kitchen Order Date', default=lambda self: fields.Datetime.now(),
                                         tracking=True)
    kitchen_waiter_name = fields.Char(string='Waiter Name', tracking=True)
    kitchen_order_ids = fields.One2many('food.order.line', 'restaurant_kitchen_order_id', tracking=True)
    kitchen_table_ids = fields.Many2many('restaurant.table', tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'), ('ordered_confirmed', 'Order Confirmed'), ('processing', 'Processing'), ('done', 'Done'),
        ('cancel', 'Cancel')],
        default='draft', tracking=True)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'restaurant.kitchen.order') or _('New')
        res = super(RestaurantKitchenOrder, self).create(vals)
        return res

    def confirm(self):
        for rec in self:
            rec.state = "ordered_confirmed"

    def processing(self):
        for rec in self:
            rec.state = "processing"

    def done(self):
        for rec in self:
            rec.state = "done"

    def draft(self):
        for rec in self:
            rec.state = "draft"

    def cancel(self):
        for rec in self:
            rec.state = "cancel"
