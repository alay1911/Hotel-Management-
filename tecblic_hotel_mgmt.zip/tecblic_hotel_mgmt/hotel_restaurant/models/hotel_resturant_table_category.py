from odoo import models, fields,api

class TableCategory(models.Model):
    _name = "table.category"
    _description = "Categories"

    name = fields.Char(string="Name")
    table_count = fields.Integer(compute='compute_table_count')

    def table_smart_button(self):
        return {
            'name': 'Tables',
            'type': 'ir.actions.act_window',
            'res_model': 'restaurant.table',
            'domain': [('table_category_id', '=', self.id)],
            'view_mode': 'tree,form',
        }
    def compute_table_count(self):
        for rec in self:
            rec.table_count = rec.env['restaurant.table'].search_count([('table_category_id', '=', rec.id)])




