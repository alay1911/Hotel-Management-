from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = "account.move"


    restaurant_order_id=fields.Many2one('restaurant.table.order',string='Order')