from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime


class RestaurantTableBooking(models.Model):
    _name = "restaurant.table.booking"
    _inherit = [
        'mail.thread', 'mail.activity.mixin'
    ]
    _description = "Restaurant"

    name = fields.Char(string="Order Reference", default=lambda self: _('New'))
    is_hotel_guest = fields.Boolean(string="Is Hotel Guest?", tracking=True)
    restaurant_table_ids = fields.Many2many('restaurant.table', domain="[('state','=','available')]")
    email = fields.Char(string='Email', tracking=True)
    phone = fields.Char(string='Phone', tracking=True)
    table_reservation_date = fields.Date(string='Table Reservation Date', tracking=True)
    num_guests = fields.Integer(string='Number of Guests', tracking=True, default=1)
    special_requests = fields.Html(string='Special Requests')
    reservation_id = fields.Many2one(comodel_name="hotel.reservation", string='Reservation No.', tracking=True,
                                     domain="[('state', '=','check_in')]")
    customer_name = fields.Many2one(comodel_name="res.partner", string="Customer", tracking=True)
    partner_address_id = fields.Many2one(comodel_name="res.partner", string="Address", tracking=True)
    folio_id = fields.Many2one(comodel_name='hotel.folio', string='Folio No.', tracking=True,
                               domain="[('reservation_id', '=',reservation_id)]")
    room_id = fields.Many2one(comodel_name='product.product', string='Room No.', domain="[('id','in',room_ids)]",
                              tracking=True)
    waiting_time = fields.Integer(string="Waiting Time", tracking=True)
    waiting_time_minutes = fields.Integer()
    start_date = fields.Datetime("Start Time", tracking=True,
                                 default=lambda self: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    end_date = fields.Datetime("End Time", tracking=True,
                               default=lambda self: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    table_booking_date = fields.Datetime("Booking Time", default=lambda self: fields.Datetime.now(), tracking=True)
    seating_preference = fields.Selection([
        ('indoor', 'Indoor'),
        ('outdoor', 'Outdoor')
    ], string='Seating Preference', tracking=True)
    tag_ids = fields.Many2many('restaurant.tag')
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("confirm", "Confirmed"),
            ("allocate", "Table Allocated"),
            ("done", "Done"),
            ("cancel", "Cancelled"),
        ],
        "state",
        readonly=True,
        default="draft",
        tracking=True
    )
    table_order = fields.Many2one('restaurant.table.order')
    menu_preferences = fields.Html(string='Menu Preferences')
    additional_comments = fields.Text(string='Additional Comments')
    company_id = fields.Many2one(comodel_name="res.company", string="Hotel", default=lambda self: self.env.company,
                                 tracking=True)
    user_id = fields.Many2one(comodel_name='res.users', string='Responsible', default=lambda self: self.env.user,
                              tracking=True)
    order_count = fields.Integer(compute='table_order_count', tracking=True)
    priority = fields.Selection([
        ('1', 'High'), ('2', 'Low'), ('3', 'Medium'), ('4', 'Very High')], String='priority', tracking=True)
    order_ids = fields.One2many(comodel_name="restaurant.table.order", inverse_name="order_reservation_id",
                                string="Orders")
    room_ids = fields.Many2many(comodel_name='product.product')
    table_occupied = fields.Boolean(string="All Table Occupied", compute='_compute_table_occupied', default=False)

    @api.model
    def create(self, vals):
        if vals.get('reference_no', ('New')) == ('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'restaurant.table.booking') or _('New')
        res = super(RestaurantTableBooking, self).create(vals)
        return res

    @api.onchange("customer_name")
    def _onchange_partner_id(self):
        if not self.customer_name:
            self.partner_address_id = False
        else:
            addr = self.customer_name.address_get(["default"])
            self.partner_address_id = addr["default"]

    @api.constrains("num_guests")
    def _check_num_of_guests(self):
        if self.num_guests <= 0:
            raise ValidationError(_("Number of Guests Should be grater than 0"))

    def get_order_data(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Allocate Table',
            'view_mode': 'list,form',
            'res_model': 'restaurant.table.order',
            'domain': [('order_reservation_id', '=', self.id)],
        }

    def table_order_count(self):
        for record in self:
            record.order_count = self.env['restaurant.table.order'].search_count(
                [('order_reservation_id', '=', self.id)])

    def action_set_to_draft(self):
        self.write({"state": "draft"})

    def table_reserved(self):
        self.write({"state": "confirm"})
        if self.state == "confirm":
            for lines in self.restaurant_table_ids:
                lines.state = 'occupied'

    def table_cancel(self):
        self.write({"state": "cancel"})

    def table_done(self):
        self.write({"state": "done"})
        if self.state == "done":
            for lines in self.restaurant_table_ids:
                lines.state = 'available'

    def create_order(self):
        self.write({"state": "allocate"})
        order_obj = self.env['restaurant.table.order']
        data = {
            'order_reservation_id': self.id,
            'order_reservation_date': self.table_booking_date,
            'table_start_date': self.start_date,
            'table_end_date': self.end_date,
            'table_ids': self.restaurant_table_ids.ids,
            'tag_ids': self.tag_ids.ids,
            'partner_id': self.customer_name.id,
        }
        if self.is_hotel_guest:
            data.update({
                'is_hotel_guest':True,
                'reservation_id' : self.reservation_id.id,
                'folio_id': self.folio_id.id
            })
        order_obj.create(data)
        return True

    @api.onchange('reservation_id')
    def _onchange_reservation(self):
        self.customer_name = self.reservation_id.partner_id

    @api.onchange('folio_id')
    def _onchange_folio(self):
        if self.folio_id:
            rooms = self.folio_id.room_line_ids.mapped('room_id')
            self.room_ids = [(6, 0, rooms.ids)]
        else:
            self.room_ids = [(5,)]

    @api.depends('num_guests')
    def _compute_table_occupied(self):
        for rec in self:
            rec.table_occupied = False
            table_data = rec.env['restaurant.table'].search([('capacity', '>=', self.num_guests)]).mapped('state')
            if 'available' not in table_data:
                rec.table_occupied = True
            else:
                rec.table_occupied = False


