from odoo import models, fields,api

class HotelTag(models.Model):
    _name = "table.tag"
    _description = "Tags"

    name = fields.Char(string="Name")
    color = fields.Integer("Color")




