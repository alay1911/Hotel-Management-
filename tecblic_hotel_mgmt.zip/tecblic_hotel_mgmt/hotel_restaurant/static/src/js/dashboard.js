odoo.define('hotel_restaurant.dashboard', function (require){
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var RestaurantDashBoard = AbstractAction.extend({
       template: 'RestaurantDashBoard',
        init: function(parent, context) {
            this._super(parent, context);
        },
        willStart: function() {
            var self = this;
            return $.when(ajax.loadLibs(this), this._super()).then(function() {
                return self.fetch_data();
            });
        },
        events: {
            'click .o_table_draft_dashboard_action': '_onTableDraftDashboardActionClicked',
            'click .o_table_confirm_dashboard_action': '_onTableConfirmDashboardActionClicked',
            'click .o_table_done_dashboard_action': '_onTableDoneDashboardActionClicked',
            'click .o_order_draft_dashboard_action': '_onOrderDraftDashboardActionClicked',
            'click .o_order_confirm_dashboard_action': '_onOrderConfirmDashboardActionClicked',
            'click .o_order_done_dashboard_action': '_onOrderDoneDashboardActionClicked',
            'click .o_kitchen_orders_dashboard_action': '_onKitchenOrdersDashboardActionClicked',
            'click .o_food_items_dashboard_action': '_onFoodItemsDashboardActionClicked',
            'click .o_food_item_types_dashboard_action': '_onFoodItemTypesDashboardActionClicked',
            'click .o_total_tables_dashboard_action': '_onTotalTablesDashboardActionClicked',
        },
        _onTableDraftDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Draft Booking Tables',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.booking',
                context: {
                    search_default_draft_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onTableConfirmDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Booking Confirmed Tables',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.booking',
                context: {
                    search_default_confirmed_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onTableDoneDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Booking Done Tables',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.booking',
                context: {
                    search_default_done_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onOrderDraftDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Draft Orders',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.order',
                context: {
                    search_default_draft_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onOrderConfirmDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Orders Confirmed',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.order',
                context: {
                    search_default_confirmed_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onOrderDoneDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Orders Done',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table.order',
                context: {
                    search_default_done_state: true,
                },
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onKitchenOrdersDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Kitchen Orders',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.kitchen.order',
                views: [[false, 'list']],
                target: 'current',
            })
        },
        _onFoodItemsDashboardActionClicked: function(e) {
              this.do_action('hotel_restaurant.product_food_item_act_window')
        },
        _onFoodItemTypesDashboardActionClicked: function(e) {
              this.do_action('hotel_restaurant.product_category_food_item_type_act_window')
        },
        _onTotalTablesDashboardActionClicked: function(e) {
            this.do_action({
                name: 'Total Tables',
                type: 'ir.actions.act_window',
                res_model: 'restaurant.table',
                views: [[false, 'list']],
                target: 'current',
            })
        },
        start: function() {
            var self = this;
            this.set("title", 'Restaurant Overview');
        },
        fetch_data: function() {
            var self = this;
            var dashboard_def = this._rpc({
                model: 'restaurant.table.booking',
                method: 'retrieve_dashboard',
            }).then(function(result) {
                self['values'] = result
            });
            return $.when(dashboard_def);
        },
    })
    core.action_registry.add('restaurant_dashboard_tags', RestaurantDashBoard);
    return RestaurantDashBoard;
})