from odoo import fields, models

class LaundryOrderReportWizard(models.TransientModel):
    _name = 'laundry.order.report.wizard'
    _description = 'laundry.order.Report.Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_laundry_order_report(self):
        data = {
            "ids": self.ids,
            "model": "laundry.order",
            "form": self.read(["start_date", "end_date"])[0],
        }
        date_records = self.env['laundry.order'].search(
            [('order_date', '>=', self.start_date), ('order_date', '<=', self.end_date)])
        laundry_data = []
        for rec in date_records:
             for line in rec.order_lines:
                laundry_data.append({
                    'name': rec.name,
                    'customer': rec.laundries_partner_id.name,
                    'hotel': rec.company_id.name,
                    'room': rec.reservation_id.name,
                    'person': rec.laundries_assigned_person.name,
                    'amount': line.amount,
                })
        data.update({
            'date_records': laundry_data,
        })
        return self.env.ref('hotel_laundry.laundry_order_report').report_action(self,data=data)
