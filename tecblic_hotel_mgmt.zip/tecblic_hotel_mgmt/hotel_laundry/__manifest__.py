{
    'name': 'Hotel Laundry',
    'summary': 'Manage Laundry works and orders For Hotels',
    'description': """
                Any services regarding laundry in hotel are completed by this module 
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['hotel_services', 'hotel_reservation', 'hotel_folio'],
    'data': [
        'security/ir.model.access.csv',
        'data/menu.xml',
        'data/washing_types_data.xml',
        'data/additional_works_data.xml',
        'data/laundry_order_sequence.xml',
        'views/hotel_laundries_views.xml',
        'views/washing_types_views.xml',
        'views/additional_works.xml',
        'report/hotel_laundry_form_view_report.xml',
        'report/laundry_order_report_template.xml',
        'views/washing_order.xml',
        'views/hotel_folio_inherit_views.xml',
        'wizard/laundry_order_wizard_view.xml',
    ],
    'demo': [],
    'application ': True,
    'auto_install': True
}
