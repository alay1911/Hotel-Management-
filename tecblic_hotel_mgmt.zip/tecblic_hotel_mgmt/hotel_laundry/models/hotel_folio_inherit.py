from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _


class HotelReservation(models.Model):
    _inherit = "hotel.folio"

    laundry_line_ids = fields.One2many('laundry.order.line', 'folio_id')

    def create_laundry_order(self):
        return {
            'name': 'Laundry Order',
            'type': 'ir.actions.act_window',
            'res_model': 'laundry.order',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_laundries_partner_id': self.reservation_id.partner_id.id,
                'default_currency': self.reservation_id.currency_id.id,
                'default_reservation_id': self.reservation_id.id,
                'default_order_date' : self.reservation_id.order_date,
                'default_folio_id': self.reservation_id.folio_ids.id,
            }
        }

    def hotel_laundry_count(self):
        for record in self:
            record.laundry_count = self.env['laundry.order'].search_count(
                [('folio_id', 'in', self.ids)])

    def laundry_smart_button(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Laundry Order'),
            'view_mode': 'tree,form',
            'res_model': 'laundry.order',
            'target': 'current',
            'domain': [('folio_id', 'in', self.ids)],
            'context': {
                'default_laundries_partner_id': self.reservation_id.partner_id.id,
                'default_currency': self.reservation_id.currency_id.id,
                'default_reservation_id': self.reservation_id.id,
                'default_order_date': self.reservation_id.order_date,
                'default_folio_id': self.reservation_id.folio_ids.id,
            }
        }


