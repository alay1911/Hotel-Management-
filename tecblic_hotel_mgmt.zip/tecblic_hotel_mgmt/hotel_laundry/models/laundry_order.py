from odoo import models, fields, api, _
from datetime import datetime, timedelta


class LaundryOrder(models.Model):
    _name = 'laundry.order'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('laundry.order')
        return super(LaundryOrder, self).create(vals)

    name = fields.Char(string="Label", copy=False)
    order_date = fields.Datetime(string="Date")
    laundries_partner_id = fields.Many2one('res.partner', string="Customer")
    currency = fields.Many2one('res.currency', string="Currency")
    laundries_assigned_person = fields.Many2one('res.users', string="Laundry Person")
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user, tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('order', 'Laundry Order'),
        ('process', 'Processing'),
        ('done', 'Done'),
        ('return', 'Returned'),
        ('cancel', 'Cancelled'),
    ], string='Status', default='draft')
    order_lines = fields.One2many('laundry.order.line', 'laundry_obj',
                                  required=1)
    product_id = fields.Many2one('product.product', string='Dress')
    work_count = fields.Integer(compute='_work_count', string='Works')
    company_id = fields.Many2one('res.company', string="Hotel Name", default=lambda self: self.env.company)
    service_type = fields.Many2one('product.category', domain=[('is_service_category', '=', True)])
    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', required=1)
    folio_id = fields.Many2one('hotel.folio')

    def laundry_order(self):
        self.state = 'order'
        for each in self:
            for obj in each.order_lines:
                self.env['washing.washing'].create(
                    {'name': obj.washing_type.name,
                     'user_id': obj.washing_type.assigned_person.id,
                     'description': obj.description,
                     'laundry_obj': obj.id,
                     'state': 'draft',
                     'washing_date': datetime.now().strftime(
                         '%Y-%m-%d %H:%M:%S')})

        folio_data = self.env['hotel.folio'].search([])
        amount = 0.0
        for rec in self.order_lines:
            amount += rec.amount
        total = amount
        for data in folio_data:
            if self.reservation_id == data.reservation_id:
                for line in data:
                    line.laundry_line_ids = [(0, 0, {
                        'laundry_obj':self.id,
                        'order_date':self.order_date,
                        'laundries_partner_id': self.laundries_partner_id.id,
                        'laundries_assigned_person': self.laundries_assigned_person.id,
                        'total_amount': total
                    })]


    def action_laundry_work(self):
        work_obj = self.env['washing.washing'].search(
            [('laundry_obj.laundry_obj.id', '=', self.id)])
        work_ids = []
        for each in work_obj:
            work_ids.append(each.id)
        view_id = self.env.ref('hotel_laundry.washing_form_view').id
        if work_ids:
            if len(work_ids) <= 1:
                value = {
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'washing.washing',
                    'view_id': view_id,
                    'type': 'ir.actions.act_window',
                    'name': _('Works'),
                    'res_id': work_ids and work_ids[0]
                }
            else:
                value = {
                    'domain': str([('id', 'in', work_ids)]),
                    'view_type': 'form',
                    'view_mode': 'tree,form',
                    'res_model': 'washing.washing',
                    'view_id': False,
                    'type': 'ir.actions.act_window',
                    'name': _('Works'),
                    # 'res_id': work_ids
                }
            return value

    def _work_count(self):
        if self.id:
            wrk_ordr_ids = self.env['washing.washing'].search([('laundry_obj.laundry_obj.id', '=', self.id)])
            self.work_count = len(wrk_ordr_ids)
        else:
            self.work_count = False

    def return_dress(self):
        self.state = 'return'

    def cancel_order(self):
        self.state = 'cancel'

    @api.onchange('reservation_id')
    def _onchange_reservation_id(self):
        for rec in self:
            for i in rec.reservation_id.folio_ids:
                return {'domain': {'folio_id': [('id', 'in', i.ids)]}}
