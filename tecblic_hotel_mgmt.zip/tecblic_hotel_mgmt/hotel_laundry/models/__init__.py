from . import laundry_order
from . import washing_types
from . import additional_works
from . import laundry_order_line
from . import washing_order
from . import hotel_folio_inherit