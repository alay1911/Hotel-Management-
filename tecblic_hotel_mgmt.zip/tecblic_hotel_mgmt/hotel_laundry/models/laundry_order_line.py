from odoo import models, fields, api, _
from datetime import datetime, timedelta


class LaundryOrderLine(models.Model):
    _name = 'laundry.order.line'

    @api.depends('washing_type', 'extra_work', 'quantity')
    def get_amount(self):
        for obj in self:
            total = obj.washing_type.amount
            for each in obj.extra_work:
                total += each.amount
            obj.amount = total

    laundry_obj = fields.Many2one('laundry.order')
    order_date = fields.Datetime(string="Order Date")
    laundries_partner_id = fields.Many2one('res.partner', string="Customer")
    laundries_assigned_person = fields.Many2one('res.users', string="Laundry Person")
    product_id = fields.Many2one('product.product', string='Items')
    description = fields.Text(string='Description')
    quantity = fields.Integer(string='No of items')
    washing_type = fields.Many2one('washing.types', string='Washing Type')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('wash', 'Washing'),
        ('extra_work', 'Make Over'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, default='draft')
    extra_work = fields.Many2one('additional.works', string='Extra Work')
    amount = fields.Float(compute='get_amount', string='Amount')
    laundry_tax = fields.Float(string="Taxes")
    folio_id = fields.Many2one('hotel.folio')
    total_amount = fields.Float(string='Total Amount')

