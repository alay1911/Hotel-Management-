from odoo import models, fields, api, _


class AdditionalWork(models.Model):
    _name = 'additional.works'

    name = fields.Char(string='Name', required=1)
    assigned_person = fields.Many2one('res.users', string='Assigned Person', required=1)
    amount = fields.Float(string='Service Charge', required=1)
