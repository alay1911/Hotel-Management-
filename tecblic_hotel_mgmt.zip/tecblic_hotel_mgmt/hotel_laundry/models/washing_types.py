from odoo import models, fields, api, _


class WashingType(models.Model):
    _name = 'washing.types'

    name = fields.Char(string='Name', required=1)
    assigned_person = fields.Many2one('res.users', string='Assigned Person', required=1)
    amount = fields.Float(string='Service Charge', required=1)
