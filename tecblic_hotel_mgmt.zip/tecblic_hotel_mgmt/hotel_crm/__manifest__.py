{
    'name': 'Hotel CRM',
    'summary': 'Manage leads ans inquiry For Hotels',
    'description': """
                Track of inquires for hotels are managed by this module 
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['crm', 'hotel_reservation', 'hotel_services'],
    'data': [
        'views/crm_lead_inherit_views.xml',
    ],
    'demo': [],
    'application ': True,
    'auto_install': True
}
