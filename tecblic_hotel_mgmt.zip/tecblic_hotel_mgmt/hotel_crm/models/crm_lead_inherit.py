from odoo import models, fields, _, api


class HotelCrmLead(models.Model):
    _inherit = "crm.lead"

    inquiry_date = fields.Datetime(string="Date")
    person = fields.Integer(string="No of Person")
    currency_id = fields.Many2one('res.currency', string="Currency")
    room_type_inquiry = fields.Many2one('product.category', string="Room Type", domain="[('is_room_type','=',True)]")
    service_type_inquiry = fields.Many2one('product.product', string="Services", domain="[('is_service','=',True)]")
    state = fields.Selection([
        ("draft", "Draft"),
        ("confirm", "Confirm"),
        ("cancel", "Cancel"),
    ], string="State", default="draft")
    reservation_active = fields.Boolean(string="Reservation Active")
    reservation_id = fields.Many2one('hotel.reservation', string="Reservation")

    def draft_inquiry(self):
        self.state = 'draft'

    def confirm_inquiry(self):
        self.state = 'confirm'
        hotel_reservation_obj = self.env['hotel.reservation']
        reservation = hotel_reservation_obj.create({
            'order_date': self.inquiry_date,
            'adults': self.person,
            'partner_id': self.partner_id.id,
            'currency_id': self.currency_id.id,
            'room_reservation_line_ids': [(0, 0, {'room_type_id': self.room_type_inquiry.id})]
        })
        reservation._onchange_partner_id()
        self.reservation_id = reservation

    def cancel_inquiry(self):
        self.state = 'cancel'

    def data_count(self):
        reservation_inquiries_count = self.search([('state', 'in', ['draft', 'confirm']),
                                                   ('reservation_active', '=', True)])
        return {
            'total_inquiry_count': len(reservation_inquiries_count.ids),
            'total_draft_inquiry': reservation_inquiries_count.filtered(lambda rec: rec.state == 'draft').ids,
            'total_draft_inquiry_count': len(
                reservation_inquiries_count.filtered(lambda rec: rec.state == 'draft').ids),
            'total_confirm_inquiry': reservation_inquiries_count.filtered(lambda rec: rec.state == 'confirm').ids,
            'total_confirm_inquiry_count': len(
                reservation_inquiries_count.filtered(lambda rec: rec.state == 'confirm').ids),
        }

    def action_reservation(self):
        return {
            'name': _('Reservation'),
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'hotel.reservation',
            'res_id' : self.reservation_id.id,
            'type': 'ir.actions.act_window',
            'target': 'current',
        }

    @api.onchange("room_type_inquiry")
    def _onchange_room_type(self):
        if self.room_type_inquiry:
            rooms = self.env['product.product'].search(
                [('is_room', '=', True), ('categ_id', '=', self.room_type_inquiry.id), ('state', '=', 'available')])
            if not rooms:
                message = {'warning': {
                    'title': _("Warning!"),
                    'message': _(
                        "No Room available for %s Room Type", self.room_type_inquiry.name
                    )
                }
                }
                self.room_type_inquiry = False
                return message
            else:
                return {'domain': {'service_type_inquiry': [('id', 'in', self.room_type_inquiry.service_ids.ids)]}}
