odoo.define('hotel_reservation.hotel_reservation_dashboard', function (require) {
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var templateCalling = AbstractAction.extend({
        template: 'HotelReservation',

        events: {
            'click .reservation-inquiry-draft-btn': '_onClickDraftInqueryRecords',
            'click .reservation-inquiry-confirm-btn': '_onClickConfirmInqueryRecords',
            'click .reservation-draft-btn': '_onClickDraftReservationRecords',
            'click .reservation-verified-btn': '_onClickVerifiedResesrvationRecords',
            'click .reservation-booked-btn': '_onClickBookedReservationRecords',
            'click .reservation-check_in-btn': '_onClickCheckInRecords',
            'click .folio-draft-btn': '_onClickFolioDraftRecords',
            'click .folio-confirm-btn': '_onClickFolioConfirmRecords',
            'click .folio-invoiced-btn': '_onClickFolioInvoiceRecords',
            'click .folio-done-btn': '_onClickFolioDonoeRecords',
            'click .room-status': '_onClickRoomStatusRecord',
            'click .book-avialble-room': '_onClickBookAvailableRoom',
            'click #create_reservation_inquiry': 'create_reservation_inquiry',
            'click #create_reservation': 'create_reservation',
            'click #create_folio': 'create_folio',
       },

        init: function(parent, data){
//            var data = true
            return this._super.apply(this, arguments);
        },

         start: function() {

            //reservation inquiry
            var self = this;
            var draft_reservation_inquiry = false;
            var confirm_reservation_inquiry = false;
            self.rec_counter()

            //reservation
            var draft_reservation_ids = false;
            var verified_reservation_ids = false;
            var booked_reservation_ids = false;
            var checkin_reservation_ids = false;
            var room_type_counts = false;
            var reservation_states = false;
            var reservation_months = false;
            self.reservation_counter()
            self.hotel_donut_chart()
            self.hotel_pie_chart()
            self.hotel_bar_chart()

            //folio
            var draft_folio_ids = false;
            var confirm_folio_ids = false;
            var invoiced_folio_ids = false;
            var done_folio_ids = false;
            self.folio_counter()

            // Room Summary
            var fromDate = new Date().toISOString().split('T')[0];
            var toDate = new Date();
            toDate.setDate(toDate.getDate() + 7);
            toDate = toDate.toISOString().split('T')[0];

            self.load_room_summary_data(fromDate,toDate)
       },

        // Room Summary Data
        load_room_summary_data: function (start_date, end_date) {
            var self = this;
            self._rpc({
                model: 'room.reservation.summary',
                method: 'get_data',
                args: [start_date, end_date],
            }).then(function (datas) {

                self.$('.room_data').html(QWeb.render('RoomSummaryTable', {
                    report_lines: datas,
                }));
            });
        },


        create_reservation_inquiry: function (ev) {
            var self = this;
            ev.preventDefault();
            var action = {
                name: "Create Reservation",
                type: 'ir.actions.act_window',
                view_mode: 'form',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                target: 'new',
            };
            this.do_action(action);
        },

        create_reservation: function (ev) {
            var self = this;
            ev.preventDefault();
            var action = {
                name: "Create Reservation",
                type: 'ir.actions.act_window',
                view_mode: 'form',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                target: 'new',
            };
            this.do_action(action);
        },

        create_folio: function (ev) {
            var self = this;
            ev.preventDefault();
            var action = {
                name: "Create Folio",
                type: 'ir.actions.act_window',
                view_mode: 'form',
                res_model: 'hotel.folio',
                views: [[false, 'form']],
                target: 'new',
            };
            this.do_action(action);
        },


        _onClickBookAvailableRoom: function (ev) {
            var self = this;
            self.do_action({
                type: 'ir.actions.act_window',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                context: {
                    'room_summary': true,
                    'room_id': parseInt($(ev.currentTarget).attr('data-room_id')),
                    'check_in': $(ev.currentTarget).attr('data-date'),
                },
                target: 'new',
            });
        },
        _onClickRoomStatusRecord: function (ev) {
            var self = this;
            self.do_action({
                type: 'ir.actions.act_window',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                res_id: parseInt($(ev.currentTarget)[0].dataset.id),
                target: 'current',
            });
        },

        // reservation inquiry
        rec_counter: function () {
            var self = this;
            self._rpc({
                model: 'crm.lead',
                method: 'data_count',
                args: [[]]
            }).then(function (datas) {
                self.$('.inquiry_count').html(datas['total_inquiry_count'])

                self.$('.reservation-inquiry-draft-btn')[0].attributes['data-badge'].nodeValue = datas['total_draft_inquiry_count']
                self.$('.reservation-inquiry-confirm-btn')[0].attributes['data-badge'].nodeValue = datas['total_confirm_inquiry_count']
                self.draft_reservation_inquiry = datas['total_draft_inquiry']
                self.confirm_reservation_inquiry = datas['total_confirm_inquiry']
                self.$('.inquiry_count').each(function () {
                    $(this).prop('Counter', 0).animate({
                        Counter: $(this).text()
                    }, {
                        duration: 5000,
                        easing: 'swing',
                        step: function (now) {
                            $(this).text(Math.ceil(now));
                        }
                    });
                });
            });
        },

        _onClickDraftInqueryRecords: function () {
            var self = this;
            this.do_action({
                name: 'Reservation Inquiry',
                type: 'ir.actions.act_window',
                res_model: 'crm.lead',
                views: [[false, 'list'], [false, 'form'], [false, 'kanban']],
                domain: [['state', '=', 'draft'], ['reservation_active', '=', true]],
                context: {
                    form_view_ref: 'hotel_crm.hotel_crm_form_view',
                    tree_view_ref: 'hotel_crm.hotel_crm_tree_view',
                    kanban_view_ref: 'hotel_crm.hotel_crm_kanban_view',
                },
            });
        },
        _onClickConfirmInqueryRecords: function () {
            var self = this;
            this.do_action({
                name: 'Reservation Inquiry',
                type: 'ir.actions.act_window',
                res_model: 'crm.lead',
                views: [[false, 'list'], [false, 'form'], [false, 'kanban']],
                domain: [['state', '=', 'confirm'], ['reservation_active', '=', true]],
                context: {
                    form_view_ref: 'hotel_crm.hotel_crm_form_view',
                    tree_view_ref: 'hotel_crm.hotel_crm_tree_view',
                    kanban_view_ref: 'hotel_crm.hotel_crm_kanban_view',
                },
            });
        },


        // reservation
        reservation_counter: function () {
            var self = this;
               self._rpc({
                   model: 'hotel.reservation',
                   method: 'reservation_dashboard_data',
                   args: [[]]
               }).then(function(datas) {
                    self.$('.reservation_count').html(datas['total_reservation_count'])
                    self.$('.reservation-draft-btn')[0].attributes['data-badge'].nodeValue = datas['total_draft_reservation_count']
                    self.$('.reservation-verified-btn')[0].attributes['data-badge'].nodeValue = datas['total_verified_reservation_count']
                    self.$('.reservation-booked-btn')[0].attributes['data-badge'].nodeValue = datas['total_booked_reservation_count']
                    self.$('.reservation-check_in-btn')[0].attributes['data-badge'].nodeValue = datas['total_check_in_reservation_count']
                    self.draft_reservation_ids = datas['total_draft_reservation']
                    self.verified_reservation_ids = datas['total_verified_reservation']
                    self.booked_reservation_ids = datas['total_booked_reservation']
                    self.checkin_reservation_ids = datas['total_check_in_reservation']
                    self.room_type_counts = datas['room_type_counts']
                    self.reservation_states = datas['reservation_states']
                    self.reservation_months = datas['reservation_months']

                    self.$('.reservation_count').each(function() {
                        $(this).prop('Counter', 0).animate({
                          Counter: $(this).text()
                        }, {
                          duration: 5000,
                          easing: 'swing',
                          step: function(now) {
                            $(this).text(Math.ceil(now));
                        }
                    });
                });

            });
        },
        _onClickDraftReservationRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.draft_reservation_ids]]
            self.get_ReservationRecords(domain)
        },
        _onClickVerifiedResesrvationRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.verified_reservation_ids]]
            self.get_ReservationRecords(domain)
        },
        _onClickBookedReservationRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.booked_reservation_ids]]
            self.get_ReservationRecords(domain)
        },
        _onClickCheckInRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.checkin_reservation_ids]]
            self.get_ReservationRecords(domain)
        },
        get_ReservationRecords: function (domain) {
            var self = this;
            self.do_action({
                name: 'Reservation',
                type: 'ir.actions.act_window',
                res_model: 'hotel.reservation',
                views: [[false, 'list'], [false, 'form']],
                domain: domain,
                target: 'current',
            });
        },

        // folio
        folio_counter: function () {
            var self = this;
            self._rpc({
                model: 'hotel.folio',
                method: 'reservation_dashboard_folio_data',
                args: [[]]
            }).then(function (datas) {
                self.$('.folio_count').html(datas['total_folio_count'])
                self.$('.folio-draft-btn')[0].attributes['data-badge'].nodeValue = datas['total_draft_folio_count']
                self.$('.folio-confirm-btn')[0].attributes['data-badge'].nodeValue = datas['total_confirm_folio_count']
                self.$('.folio-invoiced-btn')[0].attributes['data-badge'].nodeValue = datas['total_invoiced_folio_count']
                self.$('.folio-done-btn')[0].attributes['data-badge'].nodeValue = datas['total_done_folio_count']
                self.draft_folio_ids = datas['total_draft_folio']
                self.confirm_folio_ids = datas['total_confirm_folio']
                self.invoiced_folio_ids = datas['total_invoiced_folio']
                self.done_folio_ids = datas['total_done_folio']

                self.$('.folio_count').each(function () {
                    $(this).prop('Counter', 0).animate({
                        Counter: $(this).text()
                    }, {
                        duration: 5000,
                        easing: 'swing',
                        step: function (now) {
                            $(this).text(Math.ceil(now));
                        }
                    });
                });

            });
        },
        _onClickFolioDraftRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.draft_folio_ids]]
            self.get_FolioRecords(domain)
        },
        _onClickFolioConfirmRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.confirm_folio_ids]]
            self.get_FolioRecords(domain)
        },
        _onClickFolioInvoiceRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.invoiced_folio_ids]]
            self.get_FolioRecords(domain)
        },
        _onClickFolioDonoeRecords: function () {
            var self = this;
            var domain = [['id', 'in', self.done_folio_ids]]
            self.get_FolioRecords(domain)
        },
        get_FolioRecords: function (domain) {
            var self = this;
            self.do_action({
                name: 'Folio',
                type: 'ir.actions.act_window',
                res_model: 'hotel.folio',
                views: [[false, 'list'], [false, 'form']],
                domain: domain,
                target: 'current',
            });
        },

        hotel_donut_chart: function(){
            var self = this;
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable(self.reservation_states);
                var options = {
                  title: 'Reservation States',
                  pieHole: 0.4,
                };
                var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
                chart.draw(data, options);
              };
        },

        hotel_pie_chart: function(){
            var self = this;
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable(self.room_type_counts);
                var options = {
                  title: 'Rooms Occupied',
                  is3D: true,
                };
                var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
                chart.draw(data, options);
              };
        },

        hotel_bar_chart: function(){
            var self = this;
            google.charts.load('current', {'packages':['bar']});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable(self.reservation_months);
            var options = {
              chart: {},
              bars: 'vertical'
            };
            var chart = new google.charts.Bar(document.getElementById('barchart_material'));
            chart.draw(data, google.charts.Bar.convertOptions(options));
          };

        },




});
    core.action_registry.add('hotel_reservation_dashboard_tag',templateCalling);
});
