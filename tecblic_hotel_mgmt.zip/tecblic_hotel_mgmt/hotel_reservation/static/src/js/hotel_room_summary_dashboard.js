odoo.define('hotel_reservation.room_summary_dashboard', function (require) {
    "use strict";
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var rpc = require('web.rpc');
    var QWeb = core.qweb;

    var HotelRoomSummaryDashBoard = AbstractAction.extend({
        template: 'HotelRoomSummaryDashBoard',

        events: {
            'click .btn_search': '_onClickSearchRecord',
            'click .room-status': '_onClickRoomStatusRecord',
            'click .book-avialble-room': '_onClickBookAvailableRoom',
            },

        init: function(parent, action) {
           this._super(parent, action);
       },

       start: function() {
            var self = this;
            var fromDate = new Date().toISOString().split('T')[0];
            var toDate = new Date();
            toDate.setDate(toDate.getDate() + 7);
            toDate = toDate.toISOString().split('T')[0];
            self.$('.from_date').val(fromDate)
            self.$('.to_date').val(toDate)
           self.load_data(fromDate,toDate);
       },

        load_data: function (start_date,end_date) {
           var self = this;
                   var self = this;
                   self._rpc({
                       model: 'room.reservation.summary',
                       method: 'get_data',
                       args: [start_date,end_date],
                   }).then(function(datas) {

                       self.$('.room_data').html(QWeb.render('RoomSummaryTable', {
                                  report_lines : datas,
                       }));
                   });
           },

        _onClickSearchRecord: function(){
            var self = this
            var fromDate =  self.$('.from_date').val()
            var toDate =  self.$('.to_date').val()

            self.load_data(fromDate,toDate);
        },

        _onClickRoomStatusRecord: function (ev) {
            var self = this;
            self.do_action({
                type: 'ir.actions.act_window',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                res_id: parseInt($(ev.currentTarget)[0].dataset.id),
                target: 'current',
            });
        },

        _onClickBookAvailableRoom: function (ev){
            var self = this;
            self.do_action({
                type: 'ir.actions.act_window',
                res_model: 'hotel.reservation',
                views: [[false, 'form']],
                context: {
                'room_summary': true,
                'room_id': parseInt($(ev.currentTarget).attr('data-room_id')),
                'check_in': $(ev.currentTarget).attr('data-date'),
                },
                target: 'new',
            });
        },
    });

    core.action_registry.add('hotel_room_summary_dashboard', HotelRoomSummaryDashBoard);
    return HotelRoomSummaryDashBoard;
});