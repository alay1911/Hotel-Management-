from odoo import models, fields


class HotelTag(models.Model):
    _name = "hotel.tag"
    _description = "Tags"

    name = fields.Char(string="Name")
    color = fields.Integer("Color")
