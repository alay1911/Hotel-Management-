from odoo import models, fields


class DocumentFilesLines(models.Model):
    _name = "document.files"
    _description = "Document Files"

    reservation_id = fields.Many2one('hotel.reservation')
    document_categ_id = fields.Many2one('document.types', string='Document Type', required=True)
    upload_file = fields.Binary(attachment=True, required=True)
