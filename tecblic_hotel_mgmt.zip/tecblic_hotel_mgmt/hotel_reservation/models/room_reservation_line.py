from odoo import fields, models, api, _


class RoomReservationLine(models.Model):
    _name = 'room.reservation.line'
    _description = 'Room Reservation Line'
    _rec_name = 'room_id'

    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', ondelete='cascade')
    is_folio = fields.Boolean(related='reservation_id.folio_created')
    check_in_boolean = fields.Boolean(default=False, string="check-in")
    check_out_boolean = fields.Boolean(default=False, string="check-out")
    room_type_id = fields.Many2one('product.category', string='Room Type', domain="[('is_room_type', '=', True)]")
    room_id = fields.Many2one('product.product', string='Room',
                              domain="[('is_room','=',True),('categ_id','=',room_type_id),('state','=','available')]")
    capacity = fields.Integer(related='room_type_id.capacity', string="Capacity")
    tax_id = fields.Many2many('account.tax', string='Taxes')
    rate = fields.Float(string="Rate")
    check_in = fields.Datetime(string="Check-In")
    check_out = fields.Datetime(string="Check-Out")
    duration = fields.Float(compute="_compute_duration", string="Duration", store=True, default=1)
    subtotal_amount = fields.Float(compute="_compute_total_amount", string="Subtotal", store=True)
    tax_amount = fields.Float(compute="_compute_total_amount", string="Tax", store=True)
    total_amount = fields.Float(compute="_compute_total_amount", string="Total", store=True)
    state = fields.Selection(related='reservation_id.state', string="State", default='draft', tracking=True)

    def action_checkin(self):
        self.check_in = fields.Datetime.now()
        self.check_in_boolean = True
        if self.reservation_id.folio_ids:
            for rec in self.reservation_id.folio_ids:
                for line in rec.room_line_ids:
                    if line.room_id == self.room_id:
                        line.write({'check_in': self.check_in})
        history_data = self.env['product.product'].search([('is_room', '=', True)])
        for rec in history_data.rooms_history_ids:
            for line in rec:
                if line.room_id == self.room_id:
                    line.write({'check_in': self.check_in})

    # @api.model
    # def update_reservation_state(self):
    #     for reservation in self.room_reservation_line_ids:

    #         if all(line.check_out_boolean for line in reservation.room_reservation_line_ids):
    #             reservation.state = 'check_out'

    # reservations = self.mapped('reservation_id')
    # for reservation in reservations:
    #     if all(line.check_out_boolean for line in reservation.room_reservation_line_ids):
    #         reservation.state = 'checkout'

    def action_checkout(self):
        self.check_out = fields.Datetime.now()
        self.check_out_boolean = True
        self.room_id.write({'state': 'available'})

        if self.reservation_id.folio_ids:
            for rec in self.reservation_id.folio_ids:
                for line in rec.room_line_ids:
                    if line.room_id == self.room_id:
                        line.write({'check_out': self.check_out})
        history_data = self.env['product.product'].search([('is_room', '=', True)])
        for rec in history_data.rooms_history_ids:
            for line in rec:
                if line.room_id == self.room_id:
                    line.write({'check_out': self.check_out})

    @api.onchange("room_id")
    def _onchange_room(self):
        if self.room_id.list_price:
            self.rate = self.room_id.list_price
        if self.room_id.taxes_id:
            self.tax_id = self.room_id.taxes_id.ids

    @api.depends("rate", "tax_id", "room_id", "duration")
    def _compute_total_amount(self):
        for rec in self:
            res = rec.tax_id.compute_all(rec.rate, product=rec.room_id,
                                         partner=self.env['res.partner'])
            included = res['total_included'] * rec.duration
            excluded = res['total_excluded'] * rec.duration
            tax = included - excluded
            rec.subtotal_amount = excluded
            rec.tax_amount = tax
            rec.total_amount = included

    @api.depends('check_in', 'check_out')
    def _compute_duration(self):
        for rec in self:
            if rec.check_in and rec.check_out:
                dur = rec.check_out - rec.check_in
                rec.duration = dur.days + 1
            else:
                rec.duration = 1

    @api.onchange("room_type_id")
    def _onchange_room_type(self):
        if self.room_type_id:
            rooms = self.env['product.product'].search(
                [('is_room', '=', True), ('categ_id', '=', self.room_type_id.id), ('state', '=', 'available')])
            rooms_available = self.env['product.product'].search(
                [('is_room', '=', True), ('state', '=', 'available')])
            available_room_types = {}
            for room in rooms_available:
                room_type_name = room.categ_id.name
                room_name = room.name
                if room_type_name not in available_room_types:
                    available_room_types[room_type_name] = []
                available_room_types[room_type_name].append(room_name)
            if not rooms:
                formatted_room_list = ""
                for room_type, room_names in available_room_types.items():
                    room_names_str = ", ".join(room_names)
                    formatted_room_list += f"{room_type} : {room_names_str}\n"
                if not formatted_room_list:
                    msg = _("There are no rooms available at the moment!")
                else:
                    msg = _(
                        "No Room available for %s Room Type.\n\n"
                        "The following rooms are available:\n%s",
                        self.room_type_id.name,
                        formatted_room_list,
                    )
                message = {'warning': {
                    'title': _("Warning!"),
                    'message': msg
                }}
                self.room_type_id = False
                return message
