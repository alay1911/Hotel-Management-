import base64
from datetime import date, datetime, timedelta

from dateutil.relativedelta import relativedelta
from odoo import _, models, fields, api
from odoo.exceptions import ValidationError, UserError


class HotelReservation(models.Model):
    _name = "hotel.reservation"
    _inherit = [
        'mail.thread', 'mail.activity.mixin',
    ]
    _description = "Reservation"
    _order = "order_date desc,id desc"

    name = fields.Char(string="Reservation Reference", default="New")
    order_date = fields.Datetime(string="Order date", tracking=True)
    partner_id = fields.Many2one(comodel_name="res.partner", string="Guest", help="Guest", tracking=True)
    adults = fields.Integer(string="Adults", tracking=True, default=1)
    childrens = fields.Integer(string="Childrens", tracking=True)
    is_checkin = fields.Boolean()

    state = fields.Selection([('draft', 'Draft'),
                              ('reserved', 'Reserved'),
                              ('verified', 'Verified'),
                              ('booked', 'Booked'),
                              ('check_in', 'Check In'),
                              ('check_out', 'Check Out'),
                              ('done', 'Done'),
                              ('cancelled', 'Cancelled')
                              ],
                             string="State", default='draft', tracking=True)

    company_id = fields.Many2one(comodel_name="res.company", string='Hotel', default=lambda self: self.env.company,
                                 tracking=True)
    check_in = fields.Datetime(string="Expected Check-In", tracking=True)
    check_out = fields.Datetime(string="Expected Check-Out", tracking=True)
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user, tracking=True)
    room_reservation_line_ids = fields.One2many(comodel_name="room.reservation.line", inverse_name="reservation_id",
                                                string="Room Reservation Lines")
    pricelist_id = fields.Many2one(
        "product.pricelist",
        "Pricelist",
        states={"draft": [("readonly", False)]},
        help="Pricelist for current reservation.",
        tracking=True
    )
    currency_id = fields.Many2one(related='pricelist_id.currency_id', depends=["pricelist_id"], store=True,
                                  ondelete="restrict", tracking=True)
    is_multiple_folio = fields.Boolean("Create Multiple Folio", default=False)
    folio_created = fields.Boolean("Folio Created", default=False)
    document_ids = fields.One2many(comodel_name='document.files', inverse_name='reservation_id',
                                   string='Document Files')
    tag_ids = fields.Many2many('hotel.tag')
    is_all_check_out = fields.Boolean(compute="_compute_checkin_checkout", store=True)
    is_any_check_in = fields.Boolean(compute="_compute_checkin_checkout", store=True)
    is_all_check_in = fields.Boolean(compute="_compute_checkin_checkout", store=True)
    total_amount = fields.Float(compute="_compute_total_amount", string="Total", store=True)

    def _get_default_hotel_policy(self):
        return """
        <h4>Hotel Policies</h4>
        <ul>
            <li>Pets are not allowed in the hotel premises.</li>
            <li>Smoking is strictly prohibited in all areas of the hotel.</li>
            <li>Check-in time is after 2:00 PM, and check-out time is before 12:00 PM.</li>
            <li>Guests are responsible for any damages caused to hotel property during their stay.</li>
            <li>Complimentary breakfast is served daily from 7:00 AM to 10:00 AM.</li>
            <li>The hotel is not responsible for any lost or stolen items.</li>
        </ul>
        """

    hotel_policy = fields.Html(string="Hotel Policies", default=_get_default_hotel_policy)

    @api.depends('room_reservation_line_ids.total_amount')
    def _compute_total_amount(self):
        for reservation in self:
            total_amount = 0.0
            for room in reservation.room_reservation_line_ids:
                total_amount += room.total_amount

            reservation.total_amount = total_amount

    @api.depends('room_reservation_line_ids.check_in_boolean', 'room_reservation_line_ids.check_out_boolean')
    def _compute_checkin_checkout(self):
        for rec in self:
            rec.is_all_check_out = all(line.check_out_boolean for line in
                                       rec.room_reservation_line_ids) if rec.room_reservation_line_ids else False
            rec.is_any_check_in = any(line.check_in_boolean for line in
                                      rec.room_reservation_line_ids) if rec.room_reservation_line_ids else False
            rec.is_all_check_in = all(line.check_in_boolean for line in
                                      rec.room_reservation_line_ids) if rec.room_reservation_line_ids else False

            rec.update_state()

    def update_state(self):
        for rec in self:
            if rec.is_any_check_in:
                rec.state = 'check_in'

            if rec.is_any_check_in == True and rec.is_all_check_out == True:
                rec.state = 'check_out'

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'hotel.reservation') or _('New')
        res = super(HotelReservation, self).create(vals)
        return res

    def unlink(self):
        if self.folio_ids:
            self.folio_ids.unlink()
        return super(HotelReservation, self).unlink()

    @api.constrains("check_in", "check_out")
    def check_in_out_dates(self):
        if self.check_in and self.check_out:
            if self.check_in < self.order_date:
                raise ValidationError(_("""Check-in date should be greater than the current date."""))
            if self.check_out <= self.check_in:
                raise ValidationError(_("""Check-out date should be greater than Check-in date."""))

    def booked_reservation(self):
        self.state = "booked"

    def cancel_reservation(self):
        for rec in self.room_reservation_line_ids:
            rec.room_id.state = 'available'
        self.state = "cancelled"

    def reserve_reservation(self):
        self.state = "reserved"
        if self.state == "reserved":
            for line in self.room_reservation_line_ids:
                line.room_id.state = 'occupied'
        ctx = dict(self._context) or {}
        for reservation in self:
            cap = 0
            for rec in reservation.room_reservation_line_ids:
                if len(rec.room_type_id) == 0:
                    raise ValidationError(_("Please Select Rooms For Reservation."))
                cap += sum(room.capacity for room in rec.room_type_id)
            if not ctx.get("duplicate"):
                if (reservation.adults + reservation.childrens) > cap:
                    raise ValidationError(
                        _("Room Capacity Exceeded \n Please Select Rooms According to Members Accomodation."))
            if reservation.adults <= 0:
                raise ValidationError(_("Adults must be more than 1"))

    def verified_reservation(self):
        self.state = "verified"
        if not self.document_ids:
            raise UserError(_("Please upload atleast one document"))

    def _find_mail_template(self, force_confirmation_template=False):
        self.ensure_one()
        template_id = False
        if not template_id:
            template_id = self.env['ir.model.data']._xmlid_to_res_id(
                'hotel_reservation.email_template_hotel_reservation', raise_if_not_found=False)
        return template_id

    def action_send_reservation_mail(self):
        self.ensure_one()
        template_id = self._find_mail_template()
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        report_id = self.env.ref('hotel_reservation.reservation_form_view_report')._render_qweb_pdf(self.id)
        data_record = base64.b64encode(report_id[0])
        ir_values = {
            'name': self.name,
            'datas': data_record,
            'store_fname': data_record,
            'mimetype': 'application/pdf',
        }
        data_id = self.env['ir.attachment'].create(ir_values)
        ctx = {
            'default_model': 'hotel.reservation',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'default_attachment_ids': [(6, 0, [data_id.id])],
            'mark_so_as_sent': True,
            'force_email': True,
            'model_description': self.with_context(lang=lang).name,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def set_to_draft_reservation(self):
        self.update({"state": "draft"})

    def done_reservation(self):
        if self.folio_ids:
            folios = self.folio_ids.mapped('state')
            if not all(folios):
                raise UserError("All Folios should be Done")
            else:
                if folios[0] != 'done':
                    raise UserError("All Folios should be Done")
                self.state = 'done'
        elif not self.folio_ids:
            raise UserError("Cannot mark reservation as done without creating a folio.")

    def action_global_checkin(self):
        self.is_checkin = True
        for rec in self.room_reservation_line_ids:
            if rec.reservation_id.folio_ids:
                for var in rec.reservation_id.folio_ids:
                    for line in var.room_line_ids:
                        if line.room_id == rec.room_id:
                            line.write({'check_in': rec.check_in})

            rec.action_checkin()
        self.state = "check_in"

    def action_global_checkout(self):
        self.is_checkin = False
        for rec in self.room_reservation_line_ids:
            if rec.reservation_id.folio_ids:
                for var in rec.reservation_id.folio_ids:
                    for line in var.room_line_ids:
                        if line.room_id == rec.room_id:
                            line.write({'check_out': rec.check_out})

            rec.room_id.state = 'available'
            rec.action_checkout()
        self.state = "check_out"

    @api.model
    def get_reservation_details(self):
        today = datetime.today()
        this_month_start = date.today().replace(day=1)
        end_of_month = (today.replace(day=1) + relativedelta(months=1)) - timedelta(days=1)
        this_month_end = end_of_month.date()

        self._cr.execute("""SELECT COUNT(*) FROM hotel_reservation WHERE state !='done';""")
        reservation_count = self._cr.fetchall()

        self._cr.execute("""SELECT COUNT(*) FROM hotel_folio;""")
        folios_count = self._cr.fetchall()

        self._cr.execute(
            """SELECT * FROM hotel_reservation WHERE DATE(check_out) >= '%s' AND DATE(check_out) < '%s' """ % (
                this_month_start, this_month_end))
        monthly_check_out_count = self._cr.fetchall()

        self._cr.execute("""SELECT name FROM hotel_reservation WHERE state='draft'""")
        draft_name = self._cr.fetchall()

        self._cr.execute("""SELECT name FROM hotel_reservation WHERE state='confirm'""")
        confirm_name = self._cr.fetchall()

        self._cr.execute("""SELECT name FROM hotel_reservation WHERE state='cancel'""")
        cancel_name = self._cr.fetchall()

        self._cr.execute("""SELECT name FROM hotel_reservation WHERE state='done'""")
        done_name = self._cr.fetchall()

        self._cr.execute("""select hr.name, rp.name, hr.adults, hr.childrens from hotel_reservation hr 
                            left join res_partner rp on rp.id = hr.partner_id""")
        overall_details = self._cr.fetchall()

        hotel_data = {
            'reservation_count': reservation_count,
            'folios_count': folios_count,
            'monthly_check_out_count': len(monthly_check_out_count),
            'draft_name': draft_name,
            'confirm_name': confirm_name,
            'cancel_name': cancel_name,
            'done_name': done_name,
            'overall_details': overall_details,
        }
        return hotel_data

    def default_get(self, field):
        defaults = super(HotelReservation, self).default_get(field)
        defaults['order_date'] = fields.Datetime.now()
        defaults['check_in'] = fields.Datetime.now()

        if self._context.get('room_summary') and self._context.get('room_id'):
            room = self.env['product.product'].browse(self._context.get('room_id'))
            defaults['check_in'] = self._context.get('check_in') or False
            defaults['room_reservation_line_ids'] = [(0, 0, {
                'room_type_id': room.categ_id.id,
                'room_id': room.id,
            })]
        return defaults

    def _cancel_reservation(self):
        reservation = self.env['hotel.reservation'].search(
            [('check_in', '<', fields.Datetime.today()), ('state', '=', 'reserved')])
        if reservation:
            reservation.state = 'cancelled'

    def reservation_dashboard_data(self):
        reservation_count = self.search([('state', 'not in', ['cancelled'])])
        self._cr.execute("""select pc.name,count(*) from room_reservation_line rsl
                                            left join product_category pc on pc.id = rsl.room_type_id
                                            group by pc.name""")
        room_type_count = self._cr.fetchall()
        room_type_counts = [list(room_types) for room_types in room_type_count]
        room_chart_title_list = ['Hotel', 'Counts']
        room_type_counts.insert(0, room_chart_title_list)

        self._cr.execute("""select state,COUNT(*) from hotel_reservation group by state""")
        reservation_state = self._cr.fetchall()
        reservation_states = [list(states) for states in reservation_state]
        states_chart_title_list = ['States', 'Counts']
        reservation_states.insert(0, states_chart_title_list)

        self._cr.execute("""SELECT
                TO_CHAR(DATE_TRUNC('month', check_in), 'Month') AS month_name,
                COUNT(*) AS reservation_count
            FROM
                hotel_reservation
            GROUP BY
                DATE_TRUNC('month', check_in)
            ORDER BY
                DATE_TRUNC('month', check_in);""")
        reservation_month = self._cr.fetchall()
        reservation_months = [list(months) for months in reservation_month]
        month_chart_title_list = ['Months', 'Counts']
        reservation_months.insert(0, month_chart_title_list)

        return {
            'total_reservation_count': len(reservation_count.ids),
            'total_reservation': reservation_count.ids,
            'total_draft_reservation': reservation_count.filtered(lambda rec: rec.state == 'draft').ids,
            'total_draft_reservation_count': len(reservation_count.filtered(lambda rec: rec.state == 'draft').ids),
            'total_booked_reservation': reservation_count.filtered(lambda rec: rec.state == 'booked').ids,
            'total_booked_reservation_count': len(reservation_count.filtered(lambda rec: rec.state == 'booked').ids),
            'total_verified_reservation': reservation_count.filtered(lambda rec: rec.state == 'verified').ids,
            'total_verified_reservation_count': len(
                reservation_count.filtered(lambda rec: rec.state == 'verified').ids),
            'total_check_in_reservation': reservation_count.filtered(lambda rec: rec.state == 'check_in').ids,
            'total_check_in_reservation_count': len(
                reservation_count.filtered(lambda rec: rec.state == 'check_in').ids),
            'room_type_counts': room_type_counts,
            'reservation_states': reservation_states,
            'reservation_months': reservation_months,
        }

    def copy(self, default=None):
        if default is None:
            default = {}
        new_sequence = self.env['ir.sequence'].sudo().create({
            'name': f'{self.name} Sequence',
            'code': f'{self.name}_sequence_code',
        })
        default['folio_created'] = False
        default['is_multiple_folio'] = False
        default['order_date'] = fields.Datetime.now()
        default['check_in'] = fields.Datetime.to_string(datetime.now() + timedelta(minutes=1))
        default['name'] = new_sequence.next_by_code('hotel.reservation') or _('New')
        new_record = super(HotelReservation, self).copy(default=default)
        return new_record

    # # @api.depends('check_in','check_out')
    # def update_room_availability_state(self):
    #     rooms = self.env['product.product']
    #     today = datetime.today()
    #     for rec in self:
    #         if rec.check_in and rec.check_out:
    #             if rec.check_out <= today or today < rec.check_in:
    #                 rooms_record = rooms.search([('id', 'in', rec.room_reservation_line_ids.room_id.ids)])
    #                 rooms_record.write({'state': 'available'})
