from odoo import models, fields


class DocumentFiles(models.Model):
    _name = "document.types"
    _description = "Document types"

    name = fields.Char(string='Document')
