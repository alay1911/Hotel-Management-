from . import hotel_reservation
from . import room_reservation_line
from . import product_product_room_inherit
from . import product_category_room_type_inherit
from . import hotel_tags
from . import document_files
from . import document_type
from . import room_reservation_summary





