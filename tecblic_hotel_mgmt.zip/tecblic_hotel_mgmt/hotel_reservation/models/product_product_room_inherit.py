from odoo import models, fields, api


class HotelRoom(models.Model):
    _inherit = 'product.product'
    _description = "Room"

    is_room = fields.Boolean()
    categ_id = fields.Many2one(
        'product.category', 'Product Category',
        change_default=True, group_expand='_read_group_categ_id',
        required=False, help="Select category for the current product", domain="[('is_room_type', '=', True)]")
    state = fields.Selection(
        [("available", "Available"),
         ("occupied", "Occupied")],
        default="available", tracking=True
    )
    company_id = fields.Many2one(comodel_name="res.company", string='Hotel', default=lambda self: self.env.company,
                                 tracking=True)
    currency_id = fields.Many2one('res.currency', string='Currency',
                                  default=lambda self: self.env.company.currency_id.id)
    bed = fields.Integer(string='Bed', related='categ_id.bed')

    @api.onchange('categ_id')
    def onchange_rate(self):
        self.lst_price = self.categ_id.rate

    def available_room(self):
        for status in self:
            status.state = "available"

    def occupied_room(self):
        for status in self:
            status.state = "occupied"

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        context = dict(self.env.context)
        if context.get('reservation'):
            reservation = self.env['hotel.reservation'].browse(context.get('reservation'))
            if context.get('folio'):
                folio = self.env['hotel.folio'].browse(context.get('folio'))
                rooms = folio.room_line_ids.mapped('room_id').ids
            else:
                rooms = reservation.room_reservation_line_ids.mapped('room_id').ids
            args = [('id', 'in', rooms)]
        return super(HotelRoom, self)._name_search(name=name, args=args, operator=operator, limit=limit,
                                                   name_get_uid=name_get_uid)

    def make_room_available(self):
        for rec in self:
            rec.state = 'available'

    def make_room_occupied(self):
        for rec in self:
            rec.state = 'occupied'
