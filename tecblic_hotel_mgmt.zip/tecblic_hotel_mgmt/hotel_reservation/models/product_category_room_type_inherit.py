from odoo import models, fields


class RoomType(models.Model):
    _inherit = 'product.category'
    _description = "Room Type"

    is_room_type = fields.Boolean()
    capacity = fields.Integer(string="Capacity")
    rate = fields.Float(string="Rate")
    company_id = fields.Many2one(comodel_name="res.company", string='Hotel', default=lambda self: self.env.company,
                                 tracking=True)
    with_breakfast = fields.Boolean(string='With BreakFast')
    currency_id = fields.Many2one('res.currency', string='Currency',
                                  default=lambda self: self.env.company.currency_id.id)
    bed = fields.Integer(string='Bed')
