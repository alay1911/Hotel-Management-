from datetime import datetime, timedelta

from dateutil.relativedelta import relativedelta
from odoo import api, fields, models


class RoomReservationSummary(models.Model):
    _name = "room.reservation.summary"
    _description = "Room reservation summary"

    name = fields.Char("Reservation Summary", default="Reservations Summary")
    date_from = fields.Datetime(default=lambda self: datetime.now())
    date_to = fields.Datetime(
        default=lambda self: datetime.now() + relativedelta(days=30),
    )
    summary_header = fields.Text()
    room_summary = fields.Text()

    @api.model
    def get_data(self, start_date, end_date):
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        main_dict_data = {}
        dates_data = []
        all_rooms_chck_lst = []

        # // dates between start date and end date
        while start_date <= end_date:
            formatted_date = start_date
            dates_data.append(formatted_date)
            start_date += timedelta(days=1)
        main_dict_data['all_dates'] = dates_data
        all_rooms = self.env['product.product'].search([('is_room', '=', True)])
        for rooms in all_rooms:
            room_dict = {}
            rooms_data = []
            for dates in dates_data:
                reservation_lines = self.env['room.reservation.line'].search([('room_id', '=', rooms.id)])
                reservation = self.env['hotel.reservation'].search(
                    [('id', 'in', reservation_lines.ids),
                     ('state', 'in', ['reserved', 'verified', 'booked', 'check_in'])])
                if reservation and reservation.check_in.date() <= dates <= reservation.check_out.date():
                    rooms_data.append({
                        'date': dates,
                        'reservation': reservation_lines.reservation_id.ids,
                        'status': 'Reserved',
                    })
                else:
                    rooms_data.append({
                        'date': dates,
                        'room_id': rooms.id,
                        'status': 'Available',
                    })
                room_dict[rooms.name] = rooms_data
            all_rooms_chck_lst.append(room_dict)
        main_dict_data['rooms_datas'] = all_rooms_chck_lst
        return main_dict_data
