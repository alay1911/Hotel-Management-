{
    'name': 'Hotel Reservation',
    'summary': 'Manage Guest Reservations',
    'description': """
                Manage Guest Reservations.
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['mail', 'product', 'account', 'sale', 'website_sale', 'stock', 'hotel_dashboard'],
    'data': [
        'security/ir.model.access.csv',
        'security/ir.rule.xml',
        'data/cron.xml',
        'data/menu.xml',
        'data/hotel_reservation_sequence.xml',
        'data/hotel_tags.xml',
        'data/document_category_data.xml',
        'data/room_type_product_data.xml',
        'data/room_product.xml',
        'report/hotel_reservation_form_view_report.xml',
        'data/mail_template.xml',
        'report/reservation_checkin_report.xml',
        'report/reservation_checkout_report.xml',
        'report/hotel_reservation_report_template.xml',
        'report/upcoming_reservation_report.xml',
        'views/room_type_views.xml',
        'views/hotel_room_views.xml',
        'views/document_type.xml',
        'views/hotel_reservation_views.xml',
        'views/hotel_reservations_details_views.xml',
        'views/hotel_reservation_dashboard.xml',
        'views/hotel_room_summary.xml',
        'views/hotel_tags_views.xml',
        'wizard/reservation_checkin_view.xml',
        'wizard/reservation_checkout_view.xml',
        'wizard/hotel_reservation_report_views.xml',
        'wizard/upcoming_reservation_report.xml',

    ],
    'assets': {
        'web.assets_backend': [
            "https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css",
            'hotel_reservation/static/src/js/*.js',
            'hotel_reservation/static/src/css/*.css',
            'https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js',
        ],
        'web.assets_qweb': [
            'hotel_reservation/static/src/xml/hotel_reservation_template.xml',
            'hotel_reservation/static/src/xml/hotel_room_summary_template.xml',

        ],
    },
    'demo': [],
    'application ': True,
    'auto_install': True
}
