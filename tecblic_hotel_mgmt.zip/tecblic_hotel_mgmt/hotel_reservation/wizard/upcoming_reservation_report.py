# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
import datetime


class UpcomingReservationReportWizard(models.TransientModel):
    _name = 'upcoming.reservation.report.wizard'
    _description = 'Upcoming Reservation Report Wizard'

    def upcoming_reservation_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.reservation",
        }
        today_date = datetime.datetime.now()
        date_records = self.env['hotel.reservation'].search([('check_in', '>=', today_date), ('state', '=', 'reserved')])

        upcoming_reservation_data = []
        for rec in date_records:
            data_dict = {}
            room_details = []

            data_dict['name'] = rec.name
            data_dict['date'] = rec.order_date
            data_dict['guests'] = rec.partner_id.name
            data_dict['state'] = dict(rec._fields['state'].selection).get(rec.state)

            for record in rec.room_reservation_line_ids:
                room_details.append({
                    'check_in': record.check_in,
                    'check_out': record.check_out,
                    'room': record.room_id.name
                })

            data_dict['room_details'] = room_details
            upcoming_reservation_data.append(data_dict)

            data.update({
                'date_records': upcoming_reservation_data,
            })

        return self.env.ref('hotel_reservation.upcoming_reservation_report').report_action(self, data=data)
