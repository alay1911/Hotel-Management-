from odoo import fields, models
import pytz



class ReservationCheckOutWizard(models.TransientModel):
    _name = 'reservation.checkout.wizard'
    _description = 'Reservation CheckOut Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_checkout_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.reservation",
            "form": self.read(["start_date", "end_date"])[0],
        }
        date_records = self.env['hotel.reservation'].search(
            [('room_reservation_line_ids.check_out', '>=', self.start_date), ('room_reservation_line_ids.check_out', '<=', self.end_date)])
        checkout_data = []
        for rec in date_records:
            for line in rec.room_reservation_line_ids:
                checkout_data.append({
                    'name': rec.name,
                    'date':line.check_out,
                    'guests': rec.partner_id.name,
                    'room': line.room_id.name,
                })
        data.update({
            'date_records': checkout_data,
        })
        return self.env.ref('hotel_reservation.reservation_checkout_report').report_action(self,data=data)
