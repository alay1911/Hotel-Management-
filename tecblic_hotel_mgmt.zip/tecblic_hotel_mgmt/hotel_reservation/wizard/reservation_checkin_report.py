from odoo import fields, models


class ReservationCheckInWizard(models.TransientModel):
    _name = 'reservation.checkin.wizard'
    _description = 'Reservation CheckIn Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_checkin_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.reservation",
            "form": self.read(["start_date", "end_date"])[0],
        }
        date_records = self.env['hotel.reservation'].search(
            [('room_reservation_line_ids.check_in', '>=', self.start_date), ('room_reservation_line_ids.check_in', '<=', self.end_date)])      #
        checkin_data = []
        for rec in date_records:
            for line in rec.room_reservation_line_ids:
                checkin_data.append({
                    'name': rec.name,
                    'date':line.check_in,
                    'guests': rec.partner_id.name,
                    'room': line.room_id.name,
                })
        data.update({
            'date_records': checkin_data,
        })
        return self.env.ref('hotel_reservation.reservation_checkin_report').report_action(self,data=data)
