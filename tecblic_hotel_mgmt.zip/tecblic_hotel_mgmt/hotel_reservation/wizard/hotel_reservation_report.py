# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ReservationReportWizard(models.TransientModel):
    _name = 'reservation.report.wizard'
    _description = 'Reservation Report Wizard'

    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")

    def get_reservation_report(self):
        data = {
            "ids": "self.ids",
            "model": "hotel.reservation",
            "form": self.read(["start_date", "end_date"])[0],
        }

        date_records = self.env['hotel.reservation'].search(
            [('order_date', '>', self.start_date), ('order_date', '<', self.end_date)])

        reservation_data = []
        for rec in date_records:
            data_dict = {}
            room_details = []

            data_dict['start'] = self.start_date
            data_dict['name'] = rec.name
            data_dict['date'] = rec.order_date
            data_dict['guests'] = rec.partner_id.name
            data_dict['state'] = dict(rec._fields['state'].selection).get(rec.state)

            for record in rec.room_reservation_line_ids:
                room_details.append({
                    'check_in': record.check_in,
                    'check_out': record.check_out,
                    'room': record.room_id.name
                })

            data_dict['room_details'] = room_details
            reservation_data.append(data_dict)

        data.update({
            'date_records': reservation_data,
        })
        return self.env.ref('hotel_reservation.reservation_report').report_action(self, data=data)
