odoo.define('hotel_website.booking_page', function (require) {
'use strict';
    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var _t = core._t;

    publicWidget.registry.RoomBooking = publicWidget.Widget.extend({
        selector: '.room_booking_parent_cl',
        events: {
            'click .submit_btn_action': 'on_click_submit',
        },

         init: function () {
            this._super.apply(this, arguments);
         },

         start: function(){
            this._super.apply(this, arguments);
        },
        on_click_submit: function(ev){
                 var a = document.getElementById("guest_age").value;
                 if (a < 18){
                  alert("You Must be Over 18 to Reserve")
                 }
         },
   });
});
