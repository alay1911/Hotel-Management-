//Amenity Service Slider

odoo.define('hotel_website.amenity_template', function (require) {
'use strict';

var publicWidget = require('web.public.widget');
var wSaleUtils = require('website_sale.utils');
var core = require('web.core');
var _t = core._t;

var timeout;
    publicWidget.registry.websiteHomeBlogPosts = publicWidget.Widget.extend({
        selector: '.owl_blog_carousel',
        events: {
        },
        init: function () {
            this._super.apply(this, arguments);
        },
        start: function () {
            this.$el.owlCarousel({
                loop:true,
                margin:40,
                nav:true,
                dots:true,
                navText : ["<i class='fa fa-long-arrow-left'></i>","<i class='fa fa-long-arrow-right'></i>"],
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:1
                    },
                    1000:{
                        items:3
                    }
                }
            })
            return this._super.apply(this, arguments);
        },
    });
    });

