odoo.define('hotel_website.room_availability', function (require) {
'use strict';
    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var _t = core._t;

    publicWidget.registry.RoomAvailability = publicWidget.Widget.extend({
        selector: '.availability_room_parent_cl',
        events: {
            'click .btn_book_now,.btn_cancel_room': 'on_click_add_room',
        },

         init: function () {
            this._super.apply(this, arguments);
         },

         start: function(){
            this._super.apply(this, arguments);
        },


         on_click_add_room: function(ev){
             var room_id = ev.currentTarget.getAttribute('id')
             var cancel_id = ev.currentTarget.getAttribute('id')
             var btn_value=ev.currentTarget.getAttribute('btn_value')
                this._rpc({
                    route: "/room/active",
                    params: {
                        room_id: room_id,
                        cancel_id: cancel_id,
                        btn_value: btn_value,
                    },
                }).then(function (data) {
                       window.location.reload();
                    })
         },


    });

    $(document).ready(function() {
        $('.js-example-basic-multiple').select2();
    });
});
