odoo.define('hotel_website.homepage', function (require) {
'use strict';
    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var _t = core._t;

    publicWidget.registry.RoomType = publicWidget.Widget.extend({
        selector: '.homepage_parent_cl',
        events: {
                'click #eb_search_form': 'on_click_room_type',

        },

         init: function () {
            this._super.apply(this, arguments);
         },

         start: function(){
            this._super.apply(this, arguments);
        },

        on_click_room_type : function(ev){
         }

   });
});
