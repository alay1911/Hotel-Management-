odoo.define('hotel_website.guest_picker', function (require) {
'use strict';

    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var _t = core._t;

    publicWidget.registry.GuestPicker = publicWidget.Widget.extend({
        selector: '.eb-guestspicker',
        events: {
            'click .guestspicker': '_on_click_guestpicker',
            'click .plus, .minus': '_onClick_quantity',
            'click': 'stopEventPro'
        },

         _updateTotalCounts: function () {
            var adults = parseInt($('#eagle_booking_adults').val());
            var children = parseInt($('#eagle_booking_children').val());
            var rooms = parseInt($('#eagle_booking_rooms').val());

            var totalGuests = adults + children;
            var totalRooms = rooms;

            $('.gueststotal').text(totalGuests);
            $('.guestsroomstotal').text(totalRooms);
        },

         init: function () {
            this._super.apply(this, arguments);
         },

         start: function(){
            this._super.apply(this, arguments);
            this._updateTotalCounts();
            $(window).on('click', function(ev){
               $('.eb-guestspicker').removeClass('active')
            });
        },
         stopEventPro: function(event){
             event.stopPropagation()
         },
        _on_click_guestpicker: function(ev){
            this.$el.toggleClass('active');
            event.preventDefault()
        },

         _onClick_quantity: function(ev) {

             var button_target = $(ev.target)
             var old_value = parseFloat(button_target.parent().find('input').val())
             var max_value = parseFloat(button_target.parent().find('input').attr('max'))
             var min_value = parseFloat(button_target.parent().find('input').attr('min'))
                if (button_target.hasClass('plus') && max_value > 0) {
                    var newVal = parseFloat(old_value) + 1
                    if (old_value < max_value) {
                        var newVal = parseFloat(old_value) + 1
                    }
                     else {
                        var newVal = old_value
                    }
                }
                else {
                     if (old_value > min_value) {
                        var newVal = parseFloat(old_value) - 1
                    } else {
                        var newVal = min_value
                    }
                }
                button_target.parent().find("input").val(newVal);
                this._updateTotalCounts();

         },
    });
});
