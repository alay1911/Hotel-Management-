from sqlite3 import Date
from xmlrpc.client import DateTime

from odoo.addons.website.controllers.main import Website
from odoo import http, models, fields, _
import base64, os
from odoo.http import request
from datetime import datetime
from odoo.exceptions import ValidationError


class HotelAboutUs(Website):

    @http.route('/about-us', type='http', auth='public', website=True)
    def hotel_aboutus(self):
        room_id = request.env['product.product'].sudo().search_count([('is_room', '=', True)])
        reservation_id = request.env['hotel.reservation'].sudo().search_count([])
        room_type_ids = request.env['product.category'].sudo().search([('is_room_type', '=', True)])

        values = {
            'rooms': room_id,
            'reservation': reservation_id,
            'room_type_ids': room_type_ids,
        }
        return request.render('website.aboutus', values)

    @http.route('/our-services', type='http', auth='public', website=True)
    def hotel_services(self):
        service_ids = request.env['product.product'].sudo().search([('is_service', '=', True)])
        amenity_ids = request.env['product.product'].sudo().search([('is_amenity', '=', True)])

        values = {
            'service_ids': service_ids,
            'amenity_ids': amenity_ids,
        }
        return request.render('website.our_services', values)

    @http.route('/hotel-rooms', type='http', auth='public', website=True)
    def hotel_rooms(self):
        room_ids = request.env['product.product'].sudo().search([('is_room', '=', True)])
        values = {
            'room_ids': room_ids,
        }
        return request.render('hotel_website.template_website_hotel_rooms', values)

    @http.route('/', type='http', auth="public", website=True, sitemap=True)
    def home(self):
        room_type_id_lst = request.env['product.product'].sudo().search(
            [('is_room', '=', True), ('state', '=', 'available')]).mapped('categ_id').ids
        room_type_ids = request.env['product.category'].sudo().browse(room_type_id_lst)
        values = {
            'room_type_ids': room_type_ids,
        }
        return request.render('website.homepage', values)

    @http.route('/fetch/products_items', type='http', auth="public", methods=['POST'], website=True, csrf=False)
    def fetching_products(self, **kwargs):
        categ_ids = request.env['product.category'].sudo().search([('is_room_type', '=', True)])
        res = request.env["ir.ui.view"]._render_template('hotel_website.room_types_homepage', values={
            'website': request.website,
            'categ_ids': categ_ids,
        })
        if res:
            return res
        return ''

    @http.route('/room/availability', auth='public', website=True, type='http')
    def hotel_rooms_availability(self, **post):
        room_type_id_lst = request.env['product.product'].sudo().search(
            [('is_room', '=', True), ('state', '=', 'available')]).mapped('categ_id').ids
        room_type_ids = request.env['product.category'].sudo().browse(room_type_id_lst)
        room_ids = request.env['product.product'].sudo().search([('is_room', '=', True)])
        eagle_booking_checkin = post.get('eagle_booking_checkin')
        eagle_booking_checkout = post.get('eagle_booking_checkout')
        date_range = False
        if eagle_booking_checkin and eagle_booking_checkout:
            date_range = datetime.strptime(eagle_booking_checkin, '%m-%d-%Y').strftime(
                '%d/%m/%Y') + ' TO ' + datetime.strptime(eagle_booking_checkout, '%m-%d-%Y').strftime('%d/%m/%Y')
        room_type = post.get('room_id') or False

        eagle_booking_adults = post.get('eagle_booking_adults')
        eagle_booking_children = post.get('eagle_booking_children')
        eagle_booking_rooms = post.get('eagle_booking_rooms')

        book_checkin = post.get('booking_checkin')
        values = {
            'room_type_ids': room_type_ids,
            'room_ids': room_ids,
            'eagle_booking_checkin': eagle_booking_checkin,
            'eagle_booking_checkout': eagle_booking_checkout,
            'room_type': room_type,
            'eagle_booking_adults': eagle_booking_adults,
            'eagle_booking_children': eagle_booking_children,
            'eagle_booking_rooms': eagle_booking_rooms,
            'date_range': date_range,
            'book_checkin': book_checkin,
        }
        return request.render('hotel_website.availability_template_id', values)

    @http.route('/reservation-inquiry', type='http', auth="public", website=True)
    def reservation_inquiry_id(self):
        room_type_ids = request.env['product.category'].search([('is_room_type', '=', True)])
        vals = {
            'room_type_ids': room_type_ids
        }
        return request.render('hotel_website.hotel_reservation_inquiry', vals)

    @http.route('/create/inquiry', type='http', auth="public", website=True)
    def create_inquiry(self, **kw):
        vals = {
            "name": 26,
            "email_from": kw.get("email_from"),
            # "partner_id": 26,
            "currency_id": 2,
            "inquiry_date": kw.get('inquiry_date'),
            "phone": kw.get("phone"),
            "person": kw.get("person"),
            "room_type_inquiry": int(kw.get("room_id")),
            'reservation_active': True
        }
        request.env['crm.lead'].sudo().create(vals)
        return request.render('hotel_website.hotel_reservation_inquiry_thankyou')

    @http.route('/fetch/products_items', type='http', auth="public", methods=['POST'], website=True, csrf=False)
    def fetching_products(self, **kwargs):
        categ_ids = request.env['product.category'].sudo().search([('is_room_type', '=', True)])
        res = request.env["ir.ui.view"]._render_template('hotel_website.room_types_homepage', values={
            'website': request.website,
            'categ_ids': categ_ids,
        })
        if res:
            return res
        return ''

    @http.route('/room/booking', auth='user', website=True, type='http')
    def hotel_rooms_booking(self, **post):
        selected_rooms = request.env['product.product'].sudo().search([('room_selected', '=', True)])
        company_ids = request.env['res.company'].sudo().search([('id', '=', request.env.user.company_id.id)])
        room_ids = request.env['product.product'].sudo().search([('is_room', '=', True), ('state', '=', 'available')])
        partner_ids = request.env['res.users'].sudo().search([('id', '=', request.env.user.id)])
        room_type_ids = request.env['product.category'].sudo().search([('is_room_type', '=', True)])
        document_ids = request.env['document.types'].sudo().search([])
        room_booking_checkin = post.get('room_booking_checkin')
        date_checkin = False
        print("\n\n\n.................room_booking_checkin", room_booking_checkin)
        if room_booking_checkin:
            date_checkin = datetime.strptime(room_booking_checkin, '%m-%d-%Y').strftime(
                '%Y-%m-%d')
        print("\n\n\n.................room_booking_checkin", room_booking_checkin)
        room_booking_checkout = post.get('room_booking_checkout')
        date_checkout = False
        if room_booking_checkin:
            date_checkout = datetime.strptime(room_booking_checkout, '%m-%d-%Y').strftime(
                '%Y-%m-%d')
        eagle_booking_adults = post.get('adults')
        eagle_booking_children = post.get('children')
        room_type_lst = post.get('book_room_type')
        room_name = post.get('book_room_name')
        rooms_id = post.get('book_room_id')

        values = {
            'selected_rooms': selected_rooms,
            'company_ids': company_ids,
            'room_ids': room_ids,
            'room_booking_checkin': room_booking_checkin,
            'date_checkin': date_checkin,
            'room_booking_checkout': room_booking_checkout,
            'date_checkout': date_checkout,
            'partner_ids': partner_ids,
            'room_type_ids': room_type_ids,
            'document_ids': document_ids,
            'eagle_booking_adults': eagle_booking_adults,
            'eagle_booking_children': eagle_booking_children,
            'room_type_lst': room_type_lst,
            'room_name': room_name,
            'rooms_id': rooms_id,

        }
        return request.render('hotel_website.room_booking_template', values)

    @http.route('/create/reservation', type='http', auth="user", website=True)
    def create_reservation(self, **post):
        room_ids = request.env['product.product'].sudo().search([('is_room', '=', True), ('room_selected', '=', True)])
        attachment = post.get('upload_documents').read()

        booking_id = request.env['hotel.reservation'].create({
            "adults": post.get('total_adult'),
            "partner_id": int(post.get('partner_id')),
            "childrens": post.get('total_child'),
            "check_in": post.get('guest_checkin'),
            "check_out": post.get('guest_checkout'),
        })
        booking_id.write({'document_ids': [(
            0, 0, {
                'document_categ_id': int(post.get('document_id')),
                'upload_file': base64.encodebytes(attachment)
            }
        )]})
        for room in room_ids:
            booking_id.write({"room_reservation_line_ids": [
                (0, 0, {
                    'room_type_id': room.categ_id.id,
                    'room_id': room.id,
                    'capacity': room.categ_id.capacity,
                    'check_in': post.get('guest_checkin'),
                    'check_out': post.get('guest_checkout'),
                    'rate': room.lst_price,
                    'tax_id': room.taxes_id,
                })
            ], })
            room.room_selected = False
        return request.render('hotel_website.hotel_reservation_booking_thankyou')

    @http.route('/room/active', type='json', auth="public", methods=['POST'], website=True, csrf=False)
    def add_room(self, room_id=None, btn_value=None):
        active_room = request.env['product.product'].sudo().browse(int(room_id))
        if btn_value == 'selected':
            active_room.room_selected = True
        elif btn_value == 'cancel':
            active_room.room_selected = False
        value = {
            'active_room': active_room,
        }
        return value

    @http.route('/shop/payment', type='http', auth="user", website=True)
    def hotel_payments(self, **post):
        checkin_date = post.get('guest_checkin')
        checkout_date = post.get('guest_checkout')
        room_ids = request.env['product.product'].sudo().search([('is_room', '=', True), ('room_selected', '=', True)])

        values = {
            'checkin_date': checkin_date,
            'checkout_date': checkout_date,
            'room_ids': room_ids,
        }
        return request.render('hotel_website.hotel_payment_template', values)
