from odoo import models, fields, api, _


class ProductCategory(models.Model):
    _inherit = "product.product"

    room_selected=fields.Boolean()

    def get_tax_amount(self, tax):
        tax_lst = list()
        for tax in self.taxes_id:
            tax_amount = tax.amount * (self.lst_price / 100)
            tax_total = tax_amount+self.lst_price
            tax_lst.append({'name':tax.name, 'amount': tax_amount,'total':tax_total})
        return tax_lst


    def reservation_room_cron(self):
        room_ids = self.env['product.product'].sudo().search([('room_selected', '=', True)])
        for room_id in room_ids:
            room_id.room_selected = False


    def get_total_amount(self,amount):
        price_lst=list()
        for amount in self.lst_price:
            total_amount=sum(amount)
            price_lst.append({'amount':total_amount})
            print('\n\n\n\n@##############333',price_lst)
        return price_lst

