from . import res_company_inherit
from . import product_category_inherit
from . import product_product_inherit