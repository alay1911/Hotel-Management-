from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _


class ResCompany(models.Model):
    _inherit = "res.company"

    google_location = fields.Char(string="Location Link")
    primary_color = fields.Char(string="Primary Color")
    secondary_color = fields.Char(string="Secondary Color")
