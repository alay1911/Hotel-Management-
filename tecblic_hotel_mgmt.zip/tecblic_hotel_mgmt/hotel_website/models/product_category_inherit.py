from dateutil.relativedelta import relativedelta
from odoo import models, fields, api, _


class ProductCategory(models.Model):
    _inherit = "product.category"

    room_category_image = fields.Image()
