{
    'name': 'Hotel Website',
    'summary': 'Manage Website for Hotel Reservation',
    'description': """
                Managing Leads and Inquiry for hotel through e-commerce 
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['website','hotel_reservation','website_sale','website_sale_wishlist'],
    'data': [
        'data/menu.xml',
        'data/cron.xml',
        'views/website_about_template_view.xml',
        'views/website_hotel_services_template.xml',
        'views/website_hotel_rooms_template.xml',
        'views/reservation_inquiry.xml',
        'views/home_page.xml',
        'views/product_category_views.xml',
        'views/hotel_footer.xml',
        'views/res_company_views.xml',
        'views/product_product_view.xml',
        'views/website_availability_views.xml',
        'views/room_booking_page.xml',
        'views/payment_view_page.xml',

    ],
    'assets': {
        'web.assets_frontend': [
            # 'hotel_website/static/src/scss/style.scss',
            'hotel_website/static/src/scss/homepage.scss',
            'hotel_website/static/src/scss/aboutus.scss',
            'hotel_website/static/src/scss/service.scss',
            'hotel_website/static/src/scss/room_page.scss',
            'hotel_website/static/src/scss/reservation_inquiry.scss',
            'hotel_website/static/src/scss/availability_rooms.scss',
            'hotel_website/static/src/scss/room_booking.scss',
            'hotel_website/static/src/scss/payment.scss',
            'hotel_website/static/src/scss/footer.scss',
            'hotel_website/static/src/scss/color_variable.scss',

            # 'hotel_website/static/src/css/style.css',
            'hotel_website/static/src/lib/daterangepicker.css',
            'hotel_website/static/src/lib/owlcarousel/assets/owl.carousel.min.css',
            'hotel_website/static/src/js/homepage_guest_picker.js',

            'hotel_website/static/src/js/homepage_booking_datepicker.js',
            'hotel_website/static/src/js/homepage_searchbar.js',
            'hotel_website/static/src/js/booking_page.js',
            'hotel_website/static/src/js/homepage.js',
            'hotel_website/static/src/js/room_availability.js',
            'hotel_website/static/src/js/room_type_main_page_slider.js',
            'hotel_website/static/src/lib/owlcarousel/owl.carousel.min.js',
            'hotel_website/static/src/lib/daterangepicker.js',
            'hotel_website/static/src/js/service.js',
            'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css',
            'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css',
            'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js',


        ],
    },
    'demo': [],
    'application ': True,
    'auto_install': True
}
