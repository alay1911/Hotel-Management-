from . import product_product_service_inherit
from . import product_category_service_category_inherit
from . import product_product_amenity_inherit
from . import product_category_amenity
from . import product_category_breakfast
