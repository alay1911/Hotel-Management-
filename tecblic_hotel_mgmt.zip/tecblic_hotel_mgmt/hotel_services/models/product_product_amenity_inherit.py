from odoo import models, fields


class HotelAmenity(models.Model):
    _inherit = 'product.product'
    _description = "Amenity"

    is_amenity = fields.Boolean()
    amenity_category_id = fields.Many2one(comodel_name='product.category', string='Category', help='Amenity Category')

