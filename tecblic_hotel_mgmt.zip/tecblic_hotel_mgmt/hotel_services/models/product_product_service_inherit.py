from odoo import models, fields


class HotelService(models.Model):
    _inherit = 'product.product'
    _description = "Service"

    is_service = fields.Boolean()
    service_category = fields.Many2one('product.category',domain="[('is_service_category','=',True)]")
