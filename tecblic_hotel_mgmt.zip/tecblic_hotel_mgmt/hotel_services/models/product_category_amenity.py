from odoo import models, fields, api


class AmenityCategory(models.Model):
    _inherit = 'product.category'
    _description = "Amenity Category"

    is_amenity_category = fields.Boolean()
    amenity_ids = fields.Many2many(
        "product.product", 'product_amenity', 'amenity_id', 'product_id', 'Amenities',
        help="Amenities", domain="[('is_amenity','=',True)]"
    )
