from odoo import models, fields, api


class BreakfastItem(models.Model):
    _inherit = 'product.product'
    _description = "Breakfast Item"

    is_breakfast = fields.Boolean()


class BreakfastCategory(models.Model):
    _inherit = 'product.category'
    _description = "Breakfast Category"

    is_breakfast = fields.Boolean("Is Breakfast")
    breakfast_ids = fields.Many2many(
        "product.product", 'product_breakfast_rel', 'breakfast_id', 'product_id', 'Breakfast',
        domain="[('is_breakfast','=',True)]"
    )
