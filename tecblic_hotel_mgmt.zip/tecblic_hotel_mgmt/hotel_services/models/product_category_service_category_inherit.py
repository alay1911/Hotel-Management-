from odoo import models, fields, api


class ServiceCategory(models.Model):
    _inherit = 'product.category'
    _description = "Service Category"

    is_service_category = fields.Boolean()
    service_ids = fields.Many2many(
        "product.product", 'product_service', 'service_id', 'product_id', 'Services',
        help="Services", domain="[('is_service','=',True)]"
    )


