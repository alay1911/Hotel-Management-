{
    'name': 'Hotel Point of Sale',
    'summary': 'Manage Hotel Point of Sale',
    'description': """
                Manage Hotel Point of Sale.
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company': 'Tecblic Private Limited',
    'website': 'https://www.tecblic.com',
    'depends': ['base', 'point_of_sale', 'hotel_reservation', 'hotel_folio'],
    'data': [],
    'demo': [],
    'application ': True,
    'auto_install': True,

    "assets": {
        'point_of_sale.assets': [
                                    '/hotel_pos/static/src/js/hotel_pos_folio_button.js',
                                    '/hotel_pos/static/src/js/hotel_pos_FolioScreen.js',
                                ],
        'web.assets_qweb': [
                            '/hotel_pos/static/src/xml/hotel_pos_folio_button_view.xml',
                            '/hotel_pos/static/src/xml/hotel_pos_FolioScreen.xml'
                            ]
    },
}
