odoo.define('hotel_pos.FolioScreen', function(require) {
  'use strict';
  const PosComponent = require('point_of_sale.PosComponent');
  const ProductScreen = require('point_of_sale.ProductScreen');
  const {useListener} = require('web.custom_hooks');
  const Registries = require('point_of_sale.Registries');

  const models = require('point_of_sale.models');
  models.load_fields('hotel.folio', ['id','name','reservation_id','order_date','partner_id']);

  models.load_models([
    {
        model: 'hotel.folio',
        fields: ['id','name','reservation_id','order_date','partner_id'],
        args: [[]],
        domain: [],
        loaded: function (self, hotel_folios) {
            self.folios = hotel_folios;
        },
    },
  ]);

  class FolioScreen extends PosComponent {
      constructor() {
        super (... arguments);
        this.folios = this.env.pos.folios;
      }
      back() {
          this.trigger('close-temp-screen');
      }
  }

  FolioScreen.template = 'FolioScreen';
  Registries.Component.add(FolioScreen);
  return FolioScreen;
});