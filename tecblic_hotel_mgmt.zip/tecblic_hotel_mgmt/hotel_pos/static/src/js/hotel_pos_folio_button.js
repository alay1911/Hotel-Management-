odoo.define('hotel_pos.FolioButton', function(require) {
'use strict';
   const { Gui } = require('point_of_sale.Gui');
   const PosComponent = require('point_of_sale.PosComponent');
   const { posbus } = require('point_of_sale.utils');
   const ProductScreen = require('point_of_sale.ProductScreen');
   const { useListener } = require('web.custom_hooks');
   const Registries = require('point_of_sale.Registries');
   const PaymentScreen = require('point_of_sale.PaymentScreen');
   class FolioButton extends PosComponent {
        constructor() {
            super(...arguments);
            useListener('click', this.onClick);
        }
        is_available() {
            const order = this.env.pos.get_order();
            return order
        }
//        const customerId = order.get_client().id;
//        console.log("==============", this.pos.get_order().sync_info.created.user.id)
        async onClick() {
              const data = await this.rpc({
                  model: 'hotel.folio',
                  method: 'search_read',
//                  args: [[['partner_id', '=', customerId]]],
                  args: [[]],
                  kwargs: { context: this.env.session.user_context },
              });

              this.trigger('close-popup');
              this.showTempScreen('FolioScreen',{folios:data});
        }
    }

   FolioButton.template = 'FolioButton';
   ProductScreen.addControlButton({
   component: FolioButton,
   condition: function() {
   return this.env.pos;
       },
   });

   Registries.Component.add(FolioButton);
   return FolioButton;
});