from . import loyalty
from . import res_partner
from . import reservation_inherit
from . import folio_inherit
from . import res_config_settings
from . import product_inherit