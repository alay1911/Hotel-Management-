from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class HotelLoyaltyProgram(models.Model):
    _name = "loyalty.program"
    _description = 'Loyalty Program'


    name = fields.Char(string='Loyalty Program Name', index=True, required=True, translate=True, help="An internal identification for the loyalty program configuration")
    points = fields.Float(string='Point per $ spent', help="How many loyalty points are given to the customer by sold currency")
    reward_ids = fields.One2many('loyalty.reward', 'loyalty_program_id', string='Rewards')

    @api.onchange('reward_ids')
    def _check_reward_ids(self):
        if len(self.reward_ids) > 1:
            raise ValidationError('You cannot create more than 1 reward for current loyalty program')

class LoyaltyReward(models.Model):
    _name = 'loyalty.reward'
    _description = 'Loyalty Reward'


    name = fields.Char(index=True, required=True, help='An internal identification for this loyalty reward')
    loyalty_program_id = fields.Many2one('loyalty.program', string='Loyalty Program', help='The Loyalty Program this reward belongs to')
    minimum_points = fields.Float(help='The minimum amount of points the customer must have to qualify for this reward')
    reward_type = fields.Selection([('gift', 'Free Product'), ('discount', 'Discount')], required=True, help='The type of the reward', default="gift")
    gift_product_id = fields.Many2one('product.product', string='Gift Product', help='The product given as a reward')
    point_cost = fields.Float(string='Reward Cost', help="If the reward is a gift, that's the cost of the gift in points. If the reward type is a discount that's the cost in point per currency (e.g. 1 point per $)")
    discount_product_id = fields.Many2one('product.product', string='Discount Product', help='The product used to apply discounts', domain="[('is_discount','=',True)]", default=lambda self: self.env['product.product'].search([('is_discount','=',True)], limit=1))
    discount_type = fields.Selection([
        ('percentage', 'Percentage'),
        ('fixed_amount', 'Fixed Amount')], default="percentage",
        help="Percentage - Entered percentage discount will be provided\n" +
             "Amount - Entered fixed amount discount will be provided")
    discount_percentage = fields.Float(string="Discount", help='The discount in percentage, between 1 and 100')
    discount_fixed_amount = fields.Float(string="Fixed Amount", help='The discount in fixed amount')

    @api.onchange('gift_product_id','discount_percentage','discount_fixed_amount')
    def _onchange_gift_product_id(self):
        if self.gift_product_id.list_price > 0:
            self.point_cost = self.gift_product_id.list_price * self.loyalty_program_id.points
        else:
            self.point_cost = 0
        if self.reward_type == 'discount':
            if self.discount_type == 'percentage':
                self.point_cost = self.discount_percentage * self.loyalty_program_id.points
                self.discount_product_id.name = self.discount_product_id.name + ' ' + str(self.discount_percentage) + '%'
            elif self.discount_type == 'fixed_amount':
                self.point_cost = self.discount_fixed_amount * self.loyalty_program_id.points
                self.discount_product_id.name = self.discount_product_id.name + ' ' + str(round(self.discount_fixed_amount))






class ResPartner(models.Model):
    _inherit = 'account.move'

    points_spent = fields.Float('Points Spent')
    points_left = fields.Float('Points Left')


