from odoo import fields, models, api, _


class HotelReservation(models.Model):
    _inherit = 'hotel.reservation'

    loyalty_points = fields.Float(compute="_compute_loyalty_points",store=True,default=0)

    @api.onchange('room_reservation_line_ids')
    def change_points(self):
        loyalty_permit = self.env['ir.config_parameter'].sudo().get_param(
            'hotel_loyalty_program.module_hotel_loyalty')
        loyalty_permit_data = self.env['res.config.settings'].sudo().search([])

        if loyalty_permit:
            loyalty_program = [permit.loyalty_id for permit in loyalty_permit_data]
            current_loyalty = loyalty_program[-1]
            if current_loyalty:
                if self.room_reservation_line_ids:
                    self.loyalty_points = current_loyalty.points * self.total_amount
                elif len(self.room_reservation_line_ids) == 0:
                    self.loyalty_points = 0

    @api.depends('room_reservation_line_ids')
    def _compute_loyalty_points(self):
        loyalty_permit = self.env['ir.config_parameter'].sudo().get_param(
            'hotel_loyalty_program.module_hotel_loyalty')
        loyalty_permit_data = self.env['res.config.settings'].sudo().search([])

        if loyalty_permit:
            loyalty_program = [permit.loyalty_id for permit in loyalty_permit_data]
            current_loyalty = loyalty_program[-1]
            self.loyalty_points = current_loyalty.points * self.total_amount

    def booked_reservation(self):
        result = super(HotelReservation, self)
        if self.loyalty_points > 0:
            self.partner_id.write({
                'loyalty_points': (self.loyalty_points + self.partner_id.loyalty_points)
            })
        return result.booked_reservation()

    def cancel_reservation(self):
        result = super(HotelReservation, self)
        if self.loyalty_points > 0:
            self.partner_id.write({
                'loyalty_points': (self.partner_id.loyalty_points - self.loyalty_points)
            })
        return result.cancel_reservation()
