from odoo import fields, models, api, _
from odoo.exceptions import ValidationError, UserError

class HotelFolioInherit(models.Model):
    _inherit = "hotel.folio"

    def create_invoice(self):
        count = 1
        data = {
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'currency_id': self.currency_id.id,
            'date': fields.Date.today(),
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, {'sequence': count, 'name': 'Room Details', 'display_type': 'line_section'})],
            'ref': 'Folio Invoices'
        }
        for room in self.room_line_ids:
            count += 1
            data['invoice_line_ids'].append((0, 0, {
                'sequence': count,
                'product_id': room.room_id.id,
                'price_unit': room.rate,
                'tax_ids': room.tax_id.ids,
            }))
        if self.service_line_ids:
            count += 1
            data['invoice_line_ids'].append(
                (0, 0, {'sequence': count, 'name': 'Service Details', 'display_type': 'line_section'}))
            for service in self.service_line_ids:
                count += 1
                data['invoice_line_ids'].append((0, 0, {
                    'sequence': count,
                    'product_id': service.service_id.id,
                    'price_unit': service.rate,
                    'tax_ids': service.tax_id.ids,
                }))

        loyalty_permit = self.env['ir.config_parameter'].sudo().get_param(
            'hotel_loyalty_program.module_hotel_loyalty')
        loyalty_permit_data = self.env['res.config.settings'].sudo().search([])

        if loyalty_permit:
            loyalty_program = [permit.loyalty_id for permit in loyalty_permit_data]
            current_loyalty = loyalty_program[-1]
            if current_loyalty:
                # if current_loyalty.reward_ids.minimum_points > 0:
                if self.partner_id.loyalty_points > current_loyalty.reward_ids.minimum_points:
                    if current_loyalty.reward_ids.reward_type == 'gift':
                        prod = current_loyalty.reward_ids.gift_product_id.id
                        if self.partner_id.loyalty_points > 0:
                            if prod:
                                self.partner_id.loyalty_points = self.partner_id.loyalty_points - current_loyalty.reward_ids.point_cost
                                data['points_spent'] = current_loyalty.reward_ids.point_cost
                                data['points_left'] = self.partner_id.loyalty_points
                                data['invoice_line_ids'].append((0, 0, {'product_id': prod}))
                    if current_loyalty.reward_ids.reward_type == 'discount':
                        if current_loyalty.reward_ids.discount_type == 'percentage':
                            discount_product = current_loyalty.reward_ids.discount_product_id.id
                            if self.partner_id.loyalty_points > 0:
                                if discount_product:
                                    discount = room.total_amount * current_loyalty.reward_ids.discount_percentage / 100
                                    total = room.total_amount - discount
                                    self.partner_id.loyalty_points = self.partner_id.loyalty_points - current_loyalty.reward_ids.point_cost
                                    data['points_spent'] = current_loyalty.reward_ids.point_cost
                                    data['points_left'] = self.partner_id.loyalty_points
                                    data['invoice_line_ids'].append(
                                        (0, 0, {'product_id': discount_product, 'price_unit': - discount}))

                        if current_loyalty.reward_ids.discount_type == 'fixed_amount':
                            discount_product = current_loyalty.reward_ids.discount_product_id.id
                            if self.partner_id.loyalty_points > 0:
                                if discount_product:
                                    discount = current_loyalty.reward_ids.discount_fixed_amount
                                    self.partner_id.loyalty_points = self.partner_id.loyalty_points - current_loyalty.reward_ids.point_cost
                                    data['points_spent'] = current_loyalty.reward_ids.point_cost
                                    data['points_left'] = self.partner_id.loyalty_points
                                    data['invoice_line_ids'].append(
                                        (0, 0, {'product_id': discount_product, 'price_unit': - discount}))
                                    print('\n\n\n\n Discount', discount)
                elif self.partner_id.loyalty_points < current_loyalty.reward_ids.minimum_points:
                    raise ValidationError(_("You don't have enough loyalty points"))
        invoice = self.env['account.move'].create(data)
        invoice.action_post()
        self.invoice_ids = [(4, invoice.id)]
        self.state = 'invoiced'