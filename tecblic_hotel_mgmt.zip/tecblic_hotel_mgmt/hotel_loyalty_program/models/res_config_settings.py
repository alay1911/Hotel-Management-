from odoo import fields, models, api, _


class ResConfigSettings(models.TransientModel):
    _inherit = ['res.config.settings']

    module_hotel_loyalty = fields.Boolean(default=True, config_parameter='hotel_loyalty_program.module_hotel_loyalty')
    loyalty_id = fields.Many2one('loyalty.program', string='Hotel Loyalty Program', help='The loyalty program used by this hotel reservation.', config_parameter='hotel_loyalty_program.loyalty_id')

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res['module_hotel_loyalty'] = self.env['ir.config_parameter'].sudo().get_param(
            'hotel_loyalty_program.module_hotel_loyalty')
        return res

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('hotel_loyalty_program.module_hotel_loyalty',
                                                         self.module_hotel_loyalty)
        return res

