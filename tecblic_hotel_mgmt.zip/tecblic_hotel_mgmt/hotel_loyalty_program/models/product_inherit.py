from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'product.product'

    is_discount = fields.Boolean('Is Discount')