{
    'name': 'Hotel Loyalty Program',
    'summary': 'Hotel Loyalty Programs',
    'description': """
                Hotel Loyalty Programs.
      """,
    'category': 'Hotel',
    'version': '15.0.1',
    'author': 'Tecblic Private Limited',
    'company':'Tecblic Private Limited',
    'website' : 'https://www.tecblic.com',
    'depends':['base','product','hotel_reservation','account','contacts','hotel_folio'],
    'data': [
        'security/ir.model.access.csv',
        'data/discount_product.xml',
        'views/loyalty_views.xml',
        'views/reservation_inherit.xml',
        'views/res_config_settings_views.xml',
        'views/product_inherit.xml',
    ],
    'demo': [],
    'application ': True,
    'auto_install': True
}